@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CORRIGIR TABELA USUARIOS - FARMA QUANTUM

echo ============================================================
echo   CORRIGIR TABELA USUARIOS / PASSWORD_HASH
echo ============================================================
echo.
echo Este script tenta aplicar a correcao usando mysql.exe no PATH.
echo Se nao funcionar, abra o arquivo SQL no MySQL Workbench:
echo SQL_CORRIGIR_TABELA_USUARIOS_PASSWORD_HASH.sql
echo.

set /p MYSQL_USER=Usuario MySQL [usuario]: 
if "%MYSQL_USER%"=="" set "MYSQL_USER=usuario"

set /p MYSQL_DB=Banco [farmacia]: 
if "%MYSQL_DB%"=="" set "MYSQL_DB=farmacia"

echo Digite a senha quando o mysql.exe pedir.
mysql -u %MYSQL_USER% -p %MYSQL_DB% < SQL_CORRIGIR_TABELA_USUARIOS_PASSWORD_HASH.sql

echo.
pause
