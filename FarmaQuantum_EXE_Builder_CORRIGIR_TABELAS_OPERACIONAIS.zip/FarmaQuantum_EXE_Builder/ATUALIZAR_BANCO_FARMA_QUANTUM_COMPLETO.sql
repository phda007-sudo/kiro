-- =====================================================================
-- FARMA QUANTUM - ATUALIZADOR ROBUSTO DE BANCO DE DADOS
-- Corrige erros como:
--   Unknown column 'preco' in 'field list'
--   Falha ao salvar tamanhos cadastrados por tabela/coluna ausente
-- Seguro: não apaga dados; só cria tabelas/colunas/índices faltantes.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS farmacia CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE farmacia;

-- ---------------------------------------------------------------------
-- PROCEDURE AUXILIAR: adiciona coluna somente se ela não existir
-- ---------------------------------------------------------------------
DROP PROCEDURE IF EXISTS fq_add_col;
DELIMITER $$
CREATE PROCEDURE fq_add_col(IN p_table VARCHAR(128), IN p_col VARCHAR(128), IN p_def TEXT)
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table
          AND COLUMN_NAME = p_col
    ) THEN
        SET @sql = CONCAT('ALTER TABLE `', REPLACE(p_table,'`','``'), '` ADD COLUMN ', p_def);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- USUÁRIOS
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(120) UNIQUE,
    usuario VARCHAR(120),
    nome VARCHAR(255),
    password VARCHAR(255),
    password_hash VARCHAR(255),
    senha VARCHAR(255),
    nivel VARCHAR(80),
    nivel_acesso VARCHAR(80),
    permissoes LONGTEXT,
    vinculos LONGTEXT,
    ativo TINYINT DEFAULT 1,
    bloqueado TINYINT DEFAULT 0,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('usuarios','username','username VARCHAR(120)');
CALL fq_add_col('usuarios','usuario','usuario VARCHAR(120)');
CALL fq_add_col('usuarios','nome','nome VARCHAR(255)');
CALL fq_add_col('usuarios','password','password VARCHAR(255)');
CALL fq_add_col('usuarios','password_hash','password_hash VARCHAR(255)');
CALL fq_add_col('usuarios','senha','senha VARCHAR(255)');
CALL fq_add_col('usuarios','nivel','nivel VARCHAR(80)');
CALL fq_add_col('usuarios','nivel_acesso','nivel_acesso VARCHAR(80)');
CALL fq_add_col('usuarios','permissoes','permissoes LONGTEXT');
CALL fq_add_col('usuarios','vinculos','vinculos LONGTEXT');
CALL fq_add_col('usuarios','ativo','ativo TINYINT DEFAULT 1');
CALL fq_add_col('usuarios','bloqueado','bloqueado TINYINT DEFAULT 0');

-- ---------------------------------------------------------------------
-- CLIENTES / FORNECEDORES
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(80),
    nome VARCHAR(255),
    cpf VARCHAR(40),
    cnpj VARCHAR(40),
    telefone VARCHAR(80),
    whatsapp VARCHAR(80),
    endereco VARCHAR(255),
    bairro VARCHAR(120),
    observacao TEXT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('clientes','codigo','codigo VARCHAR(80)');
CALL fq_add_col('clientes','nome','nome VARCHAR(255)');
CALL fq_add_col('clientes','cpf','cpf VARCHAR(40)');
CALL fq_add_col('clientes','cnpj','cnpj VARCHAR(40)');
CALL fq_add_col('clientes','telefone','telefone VARCHAR(80)');
CALL fq_add_col('clientes','whatsapp','whatsapp VARCHAR(80)');
CALL fq_add_col('clientes','endereco','endereco VARCHAR(255)');
CALL fq_add_col('clientes','bairro','bairro VARCHAR(120)');
CALL fq_add_col('clientes','observacao','observacao TEXT');

CREATE TABLE IF NOT EXISTS fornecedores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    cnpj VARCHAR(40),
    telefone VARCHAR(80),
    email VARCHAR(160),
    endereco VARCHAR(255),
    observacao TEXT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('fornecedores','nome','nome VARCHAR(255)');
CALL fq_add_col('fornecedores','cnpj','cnpj VARCHAR(40)');
CALL fq_add_col('fornecedores','telefone','telefone VARCHAR(80)');
CALL fq_add_col('fornecedores','email','email VARCHAR(160)');
CALL fq_add_col('fornecedores','endereco','endereco VARCHAR(255)');
CALL fq_add_col('fornecedores','observacao','observacao TEXT');

-- ---------------------------------------------------------------------
-- PRODUTOS: inclui preco e aliases para evitar Unknown column 'preco'
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(80),
    codigo_barras VARCHAR(80),
    nome VARCHAR(255),
    descricao VARCHAR(255),
    categoria VARCHAR(120),
    grupo VARCHAR(120),
    unidade VARCHAR(40),
    tamanho VARCHAR(120),
    tamanho_id INT NULL,
    estoque DECIMAL(15,3) DEFAULT 0,
    estoque_minimo DECIMAL(15,3) DEFAULT 0,
    preco DECIMAL(15,2) DEFAULT 0,
    preco_custo DECIMAL(15,2) DEFAULT 0,
    preco_compra DECIMAL(15,2) DEFAULT 0,
    preco_venda DECIMAL(15,2) DEFAULT 0,
    valor DECIMAL(15,2) DEFAULT 0,
    valor_venda DECIMAL(15,2) DEFAULT 0,
    custo DECIMAL(15,2) DEFAULT 0,
    lote VARCHAR(120),
    validade DATE NULL,
    data_validade DATE NULL,
    controlar_lote_validade TINYINT DEFAULT 0,
    ativo TINYINT DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('produtos','codigo','codigo VARCHAR(80)');
CALL fq_add_col('produtos','codigo_barras','codigo_barras VARCHAR(80)');
CALL fq_add_col('produtos','nome','nome VARCHAR(255)');
CALL fq_add_col('produtos','descricao','descricao VARCHAR(255)');
CALL fq_add_col('produtos','categoria','categoria VARCHAR(120)');
CALL fq_add_col('produtos','grupo','grupo VARCHAR(120)');
CALL fq_add_col('produtos','unidade','unidade VARCHAR(40)');
CALL fq_add_col('produtos','tamanho','tamanho VARCHAR(120)');
CALL fq_add_col('produtos','tamanho_id','tamanho_id INT NULL');
CALL fq_add_col('produtos','estoque','estoque DECIMAL(15,3) DEFAULT 0');
CALL fq_add_col('produtos','estoque_minimo','estoque_minimo DECIMAL(15,3) DEFAULT 0');
CALL fq_add_col('produtos','preco','preco DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produtos','preco_custo','preco_custo DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produtos','preco_compra','preco_compra DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produtos','preco_venda','preco_venda DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produtos','valor','valor DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produtos','valor_venda','valor_venda DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produtos','custo','custo DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produtos','lote','lote VARCHAR(120)');
CALL fq_add_col('produtos','validade','validade DATE NULL');
CALL fq_add_col('produtos','data_validade','data_validade DATE NULL');
CALL fq_add_col('produtos','controlar_lote_validade','controlar_lote_validade TINYINT DEFAULT 0');
CALL fq_add_col('produtos','ativo','ativo TINYINT DEFAULT 1');
CALL fq_add_col('produtos','atualizado_em','atualizado_em TIMESTAMP NULL DEFAULT NULL');

-- Sincroniza aliases de preço, sem sobrescrever valor preenchido por valor vazio.
UPDATE produtos SET preco = preco_venda WHERE (preco IS NULL OR preco = 0) AND preco_venda IS NOT NULL AND preco_venda <> 0;
UPDATE produtos SET preco_venda = preco WHERE (preco_venda IS NULL OR preco_venda = 0) AND preco IS NOT NULL AND preco <> 0;
UPDATE produtos SET valor = preco WHERE (valor IS NULL OR valor = 0) AND preco IS NOT NULL AND preco <> 0;
UPDATE produtos SET valor_venda = preco_venda WHERE (valor_venda IS NULL OR valor_venda = 0) AND preco_venda IS NOT NULL AND preco_venda <> 0;

-- ---------------------------------------------------------------------
-- TAMANHOS / VARIAÇÕES
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tamanhos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    descricao VARCHAR(255),
    ordem INT DEFAULT 0,
    ativo TINYINT DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('tamanhos','nome','nome VARCHAR(120) NOT NULL');
CALL fq_add_col('tamanhos','descricao','descricao VARCHAR(255)');
CALL fq_add_col('tamanhos','ordem','ordem INT DEFAULT 0');
CALL fq_add_col('tamanhos','ativo','ativo TINYINT DEFAULT 1');
CALL fq_add_col('tamanhos','atualizado_em','atualizado_em TIMESTAMP NULL DEFAULT NULL');

CREATE TABLE IF NOT EXISTS produto_tamanhos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT,
    tamanho_id INT,
    tamanho VARCHAR(120),
    codigo_barras VARCHAR(80),
    estoque DECIMAL(15,3) DEFAULT 0,
    preco DECIMAL(15,2) DEFAULT 0,
    preco_venda DECIMAL(15,2) DEFAULT 0,
    ativo TINYINT DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('produto_tamanhos','produto_id','produto_id INT');
CALL fq_add_col('produto_tamanhos','tamanho_id','tamanho_id INT');
CALL fq_add_col('produto_tamanhos','tamanho','tamanho VARCHAR(120)');
CALL fq_add_col('produto_tamanhos','codigo_barras','codigo_barras VARCHAR(80)');
CALL fq_add_col('produto_tamanhos','estoque','estoque DECIMAL(15,3) DEFAULT 0');
CALL fq_add_col('produto_tamanhos','preco','preco DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produto_tamanhos','preco_venda','preco_venda DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('produto_tamanhos','ativo','ativo TINYINT DEFAULT 1');

-- Tabela alternativa caso alguma tela use nome diferente
CREATE TABLE IF NOT EXISTS tamanhos_produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT,
    nome VARCHAR(120),
    tamanho VARCHAR(120),
    descricao VARCHAR(255),
    estoque DECIMAL(15,3) DEFAULT 0,
    preco DECIMAL(15,2) DEFAULT 0,
    preco_venda DECIMAL(15,2) DEFAULT 0,
    ativo TINYINT DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('tamanhos_produtos','produto_id','produto_id INT');
CALL fq_add_col('tamanhos_produtos','nome','nome VARCHAR(120)');
CALL fq_add_col('tamanhos_produtos','tamanho','tamanho VARCHAR(120)');
CALL fq_add_col('tamanhos_produtos','descricao','descricao VARCHAR(255)');
CALL fq_add_col('tamanhos_produtos','estoque','estoque DECIMAL(15,3) DEFAULT 0');
CALL fq_add_col('tamanhos_produtos','preco','preco DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('tamanhos_produtos','preco_venda','preco_venda DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('tamanhos_produtos','ativo','ativo TINYINT DEFAULT 1');

INSERT IGNORE INTO tamanhos (id, nome, descricao, ordem, ativo) VALUES
(1,'PP','Extra pequeno',1,1),
(2,'P','Pequeno',2,1),
(3,'M','Médio',3,1),
(4,'G','Grande',4,1),
(5,'GG','Extra grande',5,1),
(6,'Único','Tamanho único',6,1);

-- ---------------------------------------------------------------------
-- VENDAS / ITENS
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vendas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(80),
    cupom VARCHAR(80),
    cliente_id INT NULL,
    cliente_nome VARCHAR(255),
    data_venda DATETIME DEFAULT CURRENT_TIMESTAMP,
    subtotal DECIMAL(15,2) DEFAULT 0,
    total DECIMAL(15,2) DEFAULT 0,
    desconto DECIMAL(15,2) DEFAULT 0,
    acrescimo DECIMAL(15,2) DEFAULT 0,
    forma_pagamento VARCHAR(120),
    usuario VARCHAR(120),
    status VARCHAR(80) DEFAULT 'FINALIZADA'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('vendas','numero','numero VARCHAR(80)');
CALL fq_add_col('vendas','cupom','cupom VARCHAR(80)');
CALL fq_add_col('vendas','cliente_id','cliente_id INT NULL');
CALL fq_add_col('vendas','cliente_nome','cliente_nome VARCHAR(255)');
CALL fq_add_col('vendas','data_venda','data_venda DATETIME DEFAULT CURRENT_TIMESTAMP');
CALL fq_add_col('vendas','subtotal','subtotal DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('vendas','total','total DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('vendas','desconto','desconto DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('vendas','acrescimo','acrescimo DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('vendas','forma_pagamento','forma_pagamento VARCHAR(120)');
CALL fq_add_col('vendas','usuario','usuario VARCHAR(120)');
CALL fq_add_col('vendas','status','status VARCHAR(80) DEFAULT ''FINALIZADA''');

CREATE TABLE IF NOT EXISTS vendas_itens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    venda_id INT,
    produto_id INT,
    produto_nome VARCHAR(255),
    quantidade DECIMAL(15,3) DEFAULT 0,
    valor_unitario DECIMAL(15,2) DEFAULT 0,
    preco DECIMAL(15,2) DEFAULT 0,
    valor_total DECIMAL(15,2) DEFAULT 0,
    tamanho VARCHAR(120),
    tamanho_id INT NULL,
    lote VARCHAR(120),
    validade DATE NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('vendas_itens','venda_id','venda_id INT');
CALL fq_add_col('vendas_itens','produto_id','produto_id INT');
CALL fq_add_col('vendas_itens','produto_nome','produto_nome VARCHAR(255)');
CALL fq_add_col('vendas_itens','quantidade','quantidade DECIMAL(15,3) DEFAULT 0');
CALL fq_add_col('vendas_itens','valor_unitario','valor_unitario DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('vendas_itens','preco','preco DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('vendas_itens','valor_total','valor_total DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('vendas_itens','tamanho','tamanho VARCHAR(120)');
CALL fq_add_col('vendas_itens','tamanho_id','tamanho_id INT NULL');
CALL fq_add_col('vendas_itens','lote','lote VARCHAR(120)');
CALL fq_add_col('vendas_itens','validade','validade DATE NULL');

-- ---------------------------------------------------------------------
-- NOTAS, LOTE, VALIDADE, FARMÁCIA
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notas_entrada (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero_nota VARCHAR(120),
    fornecedor VARCHAR(255),
    data_entrada DATE NULL,
    produto_id INT NULL,
    produto_nome VARCHAR(255),
    quantidade DECIMAL(15,3) DEFAULT 0,
    preco DECIMAL(15,2) DEFAULT 0,
    custo DECIMAL(15,2) DEFAULT 0,
    lote VARCHAR(120),
    validade DATE NULL,
    controlar_lote_validade TINYINT DEFAULT 0,
    valor_total DECIMAL(15,2) DEFAULT 0,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('notas_entrada','numero_nota','numero_nota VARCHAR(120)');
CALL fq_add_col('notas_entrada','fornecedor','fornecedor VARCHAR(255)');
CALL fq_add_col('notas_entrada','data_entrada','data_entrada DATE NULL');
CALL fq_add_col('notas_entrada','produto_id','produto_id INT NULL');
CALL fq_add_col('notas_entrada','produto_nome','produto_nome VARCHAR(255)');
CALL fq_add_col('notas_entrada','quantidade','quantidade DECIMAL(15,3) DEFAULT 0');
CALL fq_add_col('notas_entrada','preco','preco DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('notas_entrada','custo','custo DECIMAL(15,2) DEFAULT 0');
CALL fq_add_col('notas_entrada','lote','lote VARCHAR(120)');
CALL fq_add_col('notas_entrada','validade','validade DATE NULL');
CALL fq_add_col('notas_entrada','controlar_lote_validade','controlar_lote_validade TINYINT DEFAULT 0');
CALL fq_add_col('notas_entrada','valor_total','valor_total DECIMAL(15,2) DEFAULT 0');

CREATE TABLE IF NOT EXISTS estoque_lotes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT,
    produto_nome VARCHAR(255),
    lote VARCHAR(120),
    validade DATE NULL,
    quantidade DECIMAL(15,3) DEFAULT 0,
    alerta_15_dias TINYINT DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL fq_add_col('estoque_lotes','produto_id','produto_id INT');
CALL fq_add_col('estoque_lotes','produto_nome','produto_nome VARCHAR(255)');
CALL fq_add_col('estoque_lotes','lote','lote VARCHAR(120)');
CALL fq_add_col('estoque_lotes','validade','validade DATE NULL');
CALL fq_add_col('estoque_lotes','quantidade','quantidade DECIMAL(15,3) DEFAULT 0');
CALL fq_add_col('estoque_lotes','alerta_15_dias','alerta_15_dias TINYINT DEFAULT 1');

CREATE TABLE IF NOT EXISTS tratamentos_continuos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_nome VARCHAR(255),
    telefone VARCHAR(80),
    medicamento VARCHAR(255),
    dose VARCHAR(255),
    consumo_dia DECIMAL(15,3) DEFAULT 1,
    quantidade_comprada DECIMAL(15,3) DEFAULT 0,
    data_compra DATE NULL,
    data_previsao_fim DATE NULL,
    data_lembrete DATE NULL,
    ativo TINYINT DEFAULT 1,
    observacao TEXT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS prontuario_ambulatorial (
    id INT AUTO_INCREMENT PRIMARY KEY,
    paciente VARCHAR(255),
    cpf VARCHAR(40),
    telefone VARCHAR(80),
    data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
    tipo_atendimento VARCHAR(120),
    classificacao_risco VARCHAR(120),
    pressao VARCHAR(40),
    glicemia VARCHAR(40),
    temperatura VARCHAR(40),
    queixa TEXT,
    anamnese TEXT,
    conduta TEXT,
    orientacoes TEXT,
    profissional VARCHAR(255),
    observacao TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS receituario_controlados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    paciente VARCHAR(255),
    medicamento VARCHAR(255),
    prescritor VARCHAR(255),
    crm VARCHAR(80),
    tipo VARCHAR(120),
    numero_receita VARCHAR(120),
    validade_receita DATE NULL,
    lote VARCHAR(120),
    quantidade DECIMAL(15,3) DEFAULT 0,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pbm_convenios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente VARCHAR(255),
    convenio VARCHAR(255),
    autorizacao VARCHAR(120),
    beneficio VARCHAR(255),
    desconto DECIMAL(15,2) DEFAULT 0,
    validade DATE NULL,
    observacao TEXT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS campanhas_farmacia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    tipo VARCHAR(120),
    inicio DATE NULL,
    fim DATE NULL,
    canal VARCHAR(120),
    descricao TEXT,
    ativo TINYINT DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS servicos_farmaceuticos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente VARCHAR(255),
    servico VARCHAR(255),
    data_hora DATETIME NULL,
    status VARCHAR(80),
    profissional VARCHAR(255),
    valor DECIMAL(15,2) DEFAULT 0,
    observacao TEXT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS crm_farmacia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente VARCHAR(255),
    telefone VARCHAR(80),
    tipo VARCHAR(120),
    mensagem TEXT,
    data_retorno DATE NULL,
    status VARCHAR(80),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS configuracoes (
    chave VARCHAR(150) PRIMARY KEY,
    valor LONGTEXT,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO configuracoes (chave, valor) VALUES
('alerta_validade_dias','15'),
('schema_farma_quantum_ultima_correcao', NOW());

-- Índices: tentativas não críticas
DROP PROCEDURE IF EXISTS fq_add_col;
