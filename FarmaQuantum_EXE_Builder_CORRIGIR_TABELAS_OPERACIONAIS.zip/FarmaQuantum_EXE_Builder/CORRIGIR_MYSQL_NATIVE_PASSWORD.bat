@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CORRIGIR MYSQL NATIVE PASSWORD - FARMA QUANTUM

echo ============================================================
echo   CORRIGIR ERRO:
echo   Authentication plugin 'mysql_native_password' is not supported
echo ============================================================
echo.
echo O problema normalmente acontece com mysql-connector-python 9.x
echo conectando em MySQL/MariaDB/servidor configurado com mysql_native_password.
echo.
echo Esta correcao remove o conector atual e instala:
echo mysql-connector-python==8.4.0
echo.

python -m pip uninstall -y mysql-connector-python
python -m pip install --no-cache-dir "mysql-connector-python==8.4.0"

echo.
echo Versao instalada:
python -c "import mysql.connector; print(mysql.connector.__version__)"
echo.
echo Agora compile novamente usando:
echo COMPILAR_EXE_FIX_MYSQL_LOCALE_ENG.bat
echo.
pause
