# -*- coding: utf-8 -*-
"""
FARMA QUANTUM - Atualizador operacional completo

Corrige erros encontrados no log:
- Table farmacia.comandas doesn't exist
- Table farmacia.entregadores doesn't exist
- Table farmacia.servicos doesn't exist
- Table farmacia.bairros doesn't exist
- Table farmacia.cartoes doesn't exist
- Table farmacia.vendedores doesn't exist
- customers: 'cpf'
- tamanhos: 'sigla'
- Unknown column 'sigla' in 'field list'

Não apaga dados. Só cria tabelas e adiciona colunas ausentes.
"""

import sys
import getpass
import configparser
from pathlib import Path
import mysql.connector

CONFIG_PATH = Path(r"C:\Quantum\config.ini")

def log(msg):
    print("[DB-OPS-FIX]", msg)

def q(n):
    return "`" + str(n).replace("`", "``") + "`"

def qs(v):
    return "'" + str(v).replace("\\", "\\\\").replace("'", "''") + "'"

def load_cfg():
    cfg = {"host": "127.0.0.1", "port": "3306", "user": "usuario", "password": "", "database": "farmacia"}
    if CONFIG_PATH.exists():
        cp = configparser.ConfigParser()
        cp.read(str(CONFIG_PATH), encoding="utf-8")
        if cp.has_section("mysql"):
            for k in cfg:
                cfg[k] = cp.get("mysql", k, fallback=cfg[k]).strip()
    return cfg

def save_cfg(cfg):
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    cp = configparser.ConfigParser()
    cp["mysql"] = {
        "host": cfg["host"],
        "port": str(cfg["port"]),
        "user": cfg["user"],
        "password": cfg["password"],
        "database": cfg["database"],
        "allow_empty_password": "false",
    }
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        cp.write(f)
    log(r"config.ini atualizado em C:\Quantum\config.ini")

def connect_no_db(cfg):
    return mysql.connector.connect(
        host=cfg["host"], port=int(cfg["port"]), user=cfg["user"], password=cfg["password"],
        use_pure=True, autocommit=True, connect_timeout=15
    )

def connect_db(cfg):
    return mysql.connector.connect(
        host=cfg["host"], port=int(cfg["port"]), user=cfg["user"], password=cfg["password"],
        database=cfg["database"], use_pure=True, autocommit=True, connect_timeout=15
    )

def authorize_with_root(cfg):
    print()
    print("O usuário do config.ini não conectou ou não tem permissão.")
    print("Informe root/admin para liberar o usuário do sistema.")
    admin_user = input("Usuário administrador [root]: ").strip() or "root"
    admin_pass = getpass.getpass("Senha do administrador/root: ")
    sys_user = input(f"Usuário do sistema [{cfg['user']}]: ").strip() or cfg["user"]
    sys_pass = getpass.getpass("Senha para o usuário do sistema: ")
    if not sys_pass:
        print("[ERRO] Senha vazia não permitida para liberar usuário.")
        sys.exit(1)
    conn = mysql.connector.connect(
        host=cfg["host"], port=int(cfg["port"]), user=admin_user, password=admin_pass,
        use_pure=True, autocommit=True, connect_timeout=15
    )
    cur = conn.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS {q(cfg['database'])} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
    for h in ["localhost", "127.0.0.1", "%"]:
        try:
            cur.execute(f"CREATE USER IF NOT EXISTS {qs(sys_user)}@{qs(h)} IDENTIFIED BY {qs(sys_pass)}")
        except Exception as e:
            log(f"aviso CREATE USER {sys_user}@{h}: {e}")
        try:
            cur.execute(f"ALTER USER {qs(sys_user)}@{qs(h)} IDENTIFIED BY {qs(sys_pass)}")
        except Exception as e:
            log(f"aviso ALTER USER {sys_user}@{h}: {e}")
        try:
            cur.execute(f"GRANT ALL PRIVILEGES ON {q(cfg['database'])}.* TO {qs(sys_user)}@{qs(h)}")
        except Exception as e:
            log(f"aviso GRANT {sys_user}@{h}: {e}")
    cur.execute("FLUSH PRIVILEGES")
    cur.close()
    conn.close()
    cfg["user"] = sys_user
    cfg["password"] = sys_pass
    save_cfg(cfg)
    return cfg

cfg = load_cfg()
if len(sys.argv) >= 6:
    cfg = {"host": sys.argv[1], "port": sys.argv[2], "user": sys.argv[3], "password": sys.argv[4], "database": sys.argv[5]}

print("=" * 70)
print(" FARMA QUANTUM - CORRIGIR TABELAS OPERACIONAIS")
print("=" * 70)
print("Host:", cfg["host"])
print("Porta:", cfg["port"])
print("Usuário:", cfg["user"])
print("Banco:", cfg["database"])
print("Senha:", "PREENCHIDA" if cfg["password"] else "VAZIA")
print()

try:
    c = connect_no_db(cfg)
    c.close()
except Exception as e:
    log(f"conexão inicial falhou: {e}")
    escolha = input("Deseja liberar com root/admin agora? [S/n]: ").strip().lower() or "s"
    if escolha == "s":
        cfg = authorize_with_root(cfg)
    else:
        print("Cancelado.")
        sys.exit(1)

# Create DB
conn0 = connect_no_db(cfg)
cur0 = conn0.cursor()
cur0.execute(f"CREATE DATABASE IF NOT EXISTS {q(cfg['database'])} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
cur0.close()
conn0.close()

conn = connect_db(cfg)
cur = conn.cursor(dictionary=True)

def exec_safe(sql, desc=""):
    try:
        cur.execute(sql)
        if desc:
            log("OK: " + desc)
        return True
    except Exception as e:
        log("AVISO " + desc + ": " + str(e))
        return False

def cols(table):
    try:
        cur.execute(f"SHOW COLUMNS FROM {q(table)}")
        return {r["Field"].lower() for r in cur.fetchall()}
    except Exception:
        return set()

def add_col(table, col, ddl):
    if col.lower() not in cols(table):
        exec_safe(f"ALTER TABLE {q(table)} ADD COLUMN {ddl}", f"coluna {table}.{col}")

def ensure_table(table, ddl):
    exec_safe(ddl, "tabela " + table)

# Customers/clientes equivalentes
ensure_table("customers", """
CREATE TABLE IF NOT EXISTS customers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(255),
 name VARCHAR(255),
 cpf VARCHAR(40),
 cnpj VARCHAR(40),
 telefone VARCHAR(80),
 phone VARCHAR(80),
 whatsapp VARCHAR(80),
 endereco VARCHAR(255),
 address VARCHAR(255),
 bairro VARCHAR(120),
 observacao TEXT,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "nome": "nome VARCHAR(255)", "name": "name VARCHAR(255)", "cpf": "cpf VARCHAR(40)", "cnpj": "cnpj VARCHAR(40)",
    "telefone": "telefone VARCHAR(80)", "phone": "phone VARCHAR(80)", "whatsapp": "whatsapp VARCHAR(80)",
    "endereco": "endereco VARCHAR(255)", "address": "address VARCHAR(255)", "bairro": "bairro VARCHAR(120)", "observacao": "observacao TEXT"
}.items():
    add_col("customers", col, ddl)

ensure_table("clientes", """
CREATE TABLE IF NOT EXISTS clientes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(255),
 cpf VARCHAR(40),
 cnpj VARCHAR(40),
 telefone VARCHAR(80),
 whatsapp VARCHAR(80),
 endereco VARCHAR(255),
 bairro VARCHAR(120),
 observacao TEXT,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "nome": "nome VARCHAR(255)", "cpf": "cpf VARCHAR(40)", "cnpj": "cnpj VARCHAR(40)", "telefone": "telefone VARCHAR(80)",
    "whatsapp": "whatsapp VARCHAR(80)", "endereco": "endereco VARCHAR(255)", "bairro": "bairro VARCHAR(120)", "observacao": "observacao TEXT"
}.items():
    add_col("clientes", col, ddl)

# Tamanhos com sigla
ensure_table("tamanhos", """
CREATE TABLE IF NOT EXISTS tamanhos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL,
 sigla VARCHAR(30),
 descricao VARCHAR(255),
 ordem INT DEFAULT 0,
 ativo TINYINT DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 atualizado_em TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "nome": "nome VARCHAR(120) NOT NULL",
    "sigla": "sigla VARCHAR(30)",
    "descricao": "descricao VARCHAR(255)",
    "ordem": "ordem INT DEFAULT 0",
    "ativo": "ativo TINYINT DEFAULT 1",
    "atualizado_em": "atualizado_em TIMESTAMP NULL DEFAULT NULL",
}.items():
    add_col("tamanhos", col, ddl)

for sql in [
    "INSERT IGNORE INTO tamanhos (id,nome,sigla,descricao,ordem,ativo) VALUES (1,'PP','PP','Extra pequeno',1,1)",
    "INSERT IGNORE INTO tamanhos (id,nome,sigla,descricao,ordem,ativo) VALUES (2,'P','P','Pequeno',2,1)",
    "INSERT IGNORE INTO tamanhos (id,nome,sigla,descricao,ordem,ativo) VALUES (3,'M','M','Médio',3,1)",
    "INSERT IGNORE INTO tamanhos (id,nome,sigla,descricao,ordem,ativo) VALUES (4,'G','G','Grande',4,1)",
    "INSERT IGNORE INTO tamanhos (id,nome,sigla,descricao,ordem,ativo) VALUES (5,'GG','GG','Extra grande',5,1)",
    "INSERT IGNORE INTO tamanhos (id,nome,sigla,descricao,ordem,ativo) VALUES (6,'Único','UN','Tamanho único',6,1)",
    "UPDATE tamanhos SET sigla = nome WHERE (sigla IS NULL OR sigla = '') AND nome IS NOT NULL",
]:
    exec_safe(sql, "tamanhos padrão/sigla")

# Missing operational tables
ensure_table("comandas", """
CREATE TABLE IF NOT EXISTS comandas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 numero VARCHAR(80),
 nome VARCHAR(255),
 cliente_id INT NULL,
 cliente_nome VARCHAR(255),
 mesa_id INT NULL,
 status VARCHAR(80) DEFAULT 'ABERTA',
 total DECIMAL(15,2) DEFAULT 0,
 observacao TEXT,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 atualizado_em TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "numero": "numero VARCHAR(80)", "nome": "nome VARCHAR(255)", "cliente_id": "cliente_id INT NULL", "cliente_nome": "cliente_nome VARCHAR(255)",
    "mesa_id": "mesa_id INT NULL", "status": "status VARCHAR(80) DEFAULT 'ABERTA'", "total": "total DECIMAL(15,2) DEFAULT 0",
    "observacao": "observacao TEXT", "atualizado_em": "atualizado_em TIMESTAMP NULL DEFAULT NULL"
}.items():
    add_col("comandas", col, ddl)

ensure_table("entregadores", """
CREATE TABLE IF NOT EXISTS entregadores (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(255),
 telefone VARCHAR(80),
 whatsapp VARCHAR(80),
 veiculo VARCHAR(120),
 placa VARCHAR(40),
 ativo TINYINT DEFAULT 1,
 observacao TEXT,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "nome": "nome VARCHAR(255)", "telefone": "telefone VARCHAR(80)", "whatsapp": "whatsapp VARCHAR(80)",
    "veiculo": "veiculo VARCHAR(120)", "placa": "placa VARCHAR(40)", "ativo": "ativo TINYINT DEFAULT 1", "observacao": "observacao TEXT"
}.items():
    add_col("entregadores", col, ddl)

ensure_table("servicos", """
CREATE TABLE IF NOT EXISTS servicos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(255),
 descricao TEXT,
 preco DECIMAL(15,2) DEFAULT 0,
 valor DECIMAL(15,2) DEFAULT 0,
 categoria VARCHAR(120),
 ativo TINYINT DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "nome": "nome VARCHAR(255)", "descricao": "descricao TEXT", "preco": "preco DECIMAL(15,2) DEFAULT 0",
    "valor": "valor DECIMAL(15,2) DEFAULT 0", "categoria": "categoria VARCHAR(120)", "ativo": "ativo TINYINT DEFAULT 1"
}.items():
    add_col("servicos", col, ddl)

ensure_table("bairros", """
CREATE TABLE IF NOT EXISTS bairros (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(255),
 taxa_entrega DECIMAL(15,2) DEFAULT 0,
 valor_entrega DECIMAL(15,2) DEFAULT 0,
 cidade VARCHAR(120),
 ativo TINYINT DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "nome": "nome VARCHAR(255)", "taxa_entrega": "taxa_entrega DECIMAL(15,2) DEFAULT 0",
    "valor_entrega": "valor_entrega DECIMAL(15,2) DEFAULT 0", "cidade": "cidade VARCHAR(120)", "ativo": "ativo TINYINT DEFAULT 1"
}.items():
    add_col("bairros", col, ddl)

ensure_table("cartoes", """
CREATE TABLE IF NOT EXISTS cartoes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(255),
 bandeira VARCHAR(120),
 tipo VARCHAR(80),
 taxa DECIMAL(15,2) DEFAULT 0,
 dias_recebimento INT DEFAULT 0,
 ativo TINYINT DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "nome": "nome VARCHAR(255)", "bandeira": "bandeira VARCHAR(120)", "tipo": "tipo VARCHAR(80)",
    "taxa": "taxa DECIMAL(15,2) DEFAULT 0", "dias_recebimento": "dias_recebimento INT DEFAULT 0", "ativo": "ativo TINYINT DEFAULT 1"
}.items():
    add_col("cartoes", col, ddl)

ensure_table("vendedores", """
CREATE TABLE IF NOT EXISTS vendedores (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(255),
 telefone VARCHAR(80),
 comissao DECIMAL(15,2) DEFAULT 0,
 ativo TINYINT DEFAULT 1,
 observacao TEXT,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
    "nome": "nome VARCHAR(255)", "telefone": "telefone VARCHAR(80)", "comissao": "comissao DECIMAL(15,2) DEFAULT 0",
    "ativo": "ativo TINYINT DEFAULT 1", "observacao": "observacao TEXT"
}.items():
    add_col("vendedores", col, ddl)

# Produtos/price columns again
ensure_table("produtos", "CREATE TABLE IF NOT EXISTS produtos (id INT AUTO_INCREMENT PRIMARY KEY) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci")
for col, ddl in {
    "nome": "nome VARCHAR(255)", "descricao": "descricao VARCHAR(255)", "preco": "preco DECIMAL(15,2) DEFAULT 0",
    "preco_venda": "preco_venda DECIMAL(15,2) DEFAULT 0", "preco_custo": "preco_custo DECIMAL(15,2) DEFAULT 0",
    "estoque": "estoque DECIMAL(15,3) DEFAULT 0", "tamanho": "tamanho VARCHAR(120)", "tamanho_id": "tamanho_id INT NULL",
    "lote": "lote VARCHAR(120)", "validade": "validade DATE NULL", "ativo": "ativo TINYINT DEFAULT 1"
}.items():
    add_col("produtos", col, ddl)

# Config marker
ensure_table("configuracoes", "CREATE TABLE IF NOT EXISTS configuracoes (chave VARCHAR(150) PRIMARY KEY, valor LONGTEXT, atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci")
exec_safe("INSERT INTO configuracoes (chave, valor) VALUES ('schema_farma_quantum_operacional_ok', NOW()) ON DUPLICATE KEY UPDATE valor = NOW()", "marca schema operacional")

cur.close()
conn.close()
log("CORREÇÃO OPERACIONAL CONCLUÍDA COM SUCESSO.")
print("Abra o Farma Quantum novamente.")
