# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules, collect_data_files, copy_metadata

block_cipher = None

hiddenimports = []
hiddenimports += collect_submodules('mysql.connector')
hiddenimports += collect_submodules('mysql.connector.locales')
hiddenimports += [
    'mysql.connector.locales.eng.client_error',
    'mysql.connector.locales.client_error',
    'mysql.connector.connection',
    'mysql.connector.pooling',
    'mysql.connector.errorcode',
]

datas = []
datas += collect_data_files('mysql.connector')
try:
    datas += copy_metadata('mysql-connector-python')
except Exception:
    pass

a = Analysis(
    ['Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py'],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='FarmaQuantum',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='farmacia_moderno.ico',
)
