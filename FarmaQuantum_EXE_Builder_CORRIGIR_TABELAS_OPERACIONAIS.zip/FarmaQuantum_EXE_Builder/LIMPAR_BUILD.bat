@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist __pycache__ rmdir /s /q __pycache__
if exist FarmaQuantum.spec del /q FarmaQuantum.spec
echo Build limpo.
pause
