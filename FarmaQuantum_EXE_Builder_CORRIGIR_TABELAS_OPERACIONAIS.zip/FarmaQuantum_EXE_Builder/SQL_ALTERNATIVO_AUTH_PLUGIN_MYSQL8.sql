-- CORREÇÃO ALTERNATIVA - MYSQL AUTH PLUGIN
-- Use somente no MySQL Workbench com usuário administrador.
-- Esta alternativa altera o usuário para caching_sha2_password.
-- Se você usa MariaDB ou MySQL antigo, prefira usar o BAT CORRIGIR_MYSQL_NATIVE_PASSWORD.bat.

ALTER USER 'root'@'localhost' IDENTIFIED WITH caching_sha2_password BY 'SUA_SENHA_ROOT_AQUI';
ALTER USER 'usuario'@'localhost' IDENTIFIED WITH caching_sha2_password BY 'SUA_SENHA_USUARIO_AQUI';
ALTER USER 'usuario'@'127.0.0.1' IDENTIFIED WITH caching_sha2_password BY 'SUA_SENHA_USUARIO_AQUI';
FLUSH PRIVILEGES;
