# -*- mode: python ; coding: utf-8 -*-
# Spec opcional. Normalmente use COMPILAR_EXE_NOCONSOLE_ONEFILE.bat.
from PyInstaller.utils.hooks import collect_all

datas = [('farmacia_moderno.ico', '.')]
binaries = []
hiddenimports = [
    'tkinter', 'tkinter.ttk', 'ttkbootstrap', 'PIL', 'PIL.Image',
    'mysql.connector', 'reportlab', 'fpdf', 'openpyxl', 'psutil',
    'serial', 'bleak', 'qrcode', 'pyttsx3', 'win32api', 'win32print'
]

for pkg in ['ttkbootstrap', 'PIL', 'reportlab', 'openpyxl', 'qrcode']:
    try:
        pkg_datas, pkg_bins, pkg_hidden = collect_all(pkg)
        datas += pkg_datas
        binaries += pkg_bins
        hiddenimports += pkg_hidden
    except Exception:
        pass

a = Analysis(
    ['Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='FarmaQuantum',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir='C:\\ProgramData\\FarmaQuantumRuntime',
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['farmacia_moderno.ico'],
)
