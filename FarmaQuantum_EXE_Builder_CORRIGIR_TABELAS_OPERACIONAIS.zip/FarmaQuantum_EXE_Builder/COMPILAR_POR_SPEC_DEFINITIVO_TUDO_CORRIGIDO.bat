@echo off
chcp 65001 >nul
cd /d "%~dp0"
title COMPILAR POR SPEC DEFINITIVO - FARMA QUANTUM

echo ============================================================
echo   COMPILAR POR SPEC DEFINITIVO
echo ============================================================
echo.
python -m pip install "ttkbootstrap==1.20.3" "mysql-connector-python==8.4.0" --prefer-binary
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
python -m PyInstaller --clean --noconfirm FarmaQuantum_DEFINITIVO_TUDO_CORRIGIDO.spec
echo.
echo EXE em dist\FarmaQuantum.exe
pause
