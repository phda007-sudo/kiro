@echo off
REM FARMA QUANTUM CHECK MYSQL CONNECTOR VERSION
python -c "import mysql.connector; print('[MYSQL CONNECTOR]', mysql.connector.__version__)"
REM FARMA QUANTUM FIX LOCK DEFINITIVO
if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
if exist C:\Quantum\.pdv_quantum_ultra.lock del /f /q C:\Quantum\.pdv_quantum_ultra.lock
chcp 65001 >nul
cd /d "%~dp0"
title COMPILAR POR SPEC - FIX MYSQL LOCALE ENG

echo ============================================================
echo   COMPILAR POR SPEC - FIX MYSQL LOCALE ENG
echo ============================================================
echo.
if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock

python -m PyInstaller --clean --noconfirm FarmaQuantum_FIX_MYSQL_LOCALE_ENG.spec

echo.
echo Se tudo deu certo, o EXE esta em:
echo dist\FarmaQuantum.exe
echo.
pause


REM FIX MYSQL AUTH PLUGINS
python -m PyInstaller ^
 --onefile ^
 --noconsole ^
 --clean ^
 --name FarmaQuantum ^
 --icon farmacia_moderno.ico ^
 --hidden-import=mysql.connector.plugins.mysql_native_password ^
 --hidden-import=mysql.connector.plugins.caching_sha2_password ^
 --hidden-import=mysql.connector.plugins.sha256_password ^
 --hidden-import=mysql.connector.plugins.mysql_clear_password ^
 --collect-submodules=mysql.connector.plugins ^
 --collect-submodules=mysql.connector ^
 --collect-data=mysql.connector ^ ^
 --hidden-import=ttkbootstrap ^
 --hidden-import=ttkbootstrap.style ^
 --hidden-import=ttkbootstrap.widgets ^
 --hidden-import=ttkbootstrap.dialogs ^
 --hidden-import=ttkbootstrap.constants ^
 --hidden-import=ttkbootstrap.icons ^
 --collect-submodules=ttkbootstrap ^
 --collect-data=ttkbootstrap
 Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
