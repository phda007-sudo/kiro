@echo off
chcp 65001 >nul
cd /d "%~dp0"
title FARMA QUANTUM - PREPARAR, AUTOCORRIGIR E COMPILAR TUDO

echo ============================================================
echo   FARMA QUANTUM - PREPARAR / AUTOCORRIGIR / COMPILAR
echo   SEM TRAVA DE SENHA VAZIA PARA COMPILAR
echo ============================================================
echo.
echo Pasta atual:
cd
echo.

if not exist "Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py" (
    echo [ERRO] O arquivo Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py nao foi encontrado nesta pasta.
    echo Extraia o ZIP completo e execute este BAT dentro da pasta FarmaQuantum_EXE_Builder.
    pause
    exit /b 1
)

echo [1/6] Instalando/corrigindo bibliotecas obrigatorias...
python -m pip install --upgrade pip setuptools wheel --prefer-binary

if exist "requirements.txt" (
    python -m pip install -r requirements.txt --prefer-binary
) else (
    echo [AVISO] requirements.txt nao encontrado. Instalando conjunto minimo obrigatorio...
    python -m pip install pyinstaller pyinstaller-hooks-contrib ttkbootstrap==1.20.3 mysql-connector-python==8.4.0 Pillow reportlab fpdf2 openpyxl qrcode pyserial flask flask-cors flask-socketio bleak --prefer-binary
)

python -m pip install "psutil==5.9.8" --only-binary=:all: --prefer-binary
python -m pip install "ttkbootstrap==1.20.3" "mysql-connector-python==8.4.0" --prefer-binary

echo.
echo [2/6] Garantindo config.ini...
if not exist "C:\Quantum" mkdir "C:\Quantum"
if not exist "C:\Quantum\config.ini" (
  echo [mysql]>"C:\Quantum\config.ini"
  echo host = 127.0.0.1>>"C:\Quantum\config.ini"
  echo port = 3306>>"C:\Quantum\config.ini"
  echo user = usuario>>"C:\Quantum\config.ini"
  echo password = >>"C:\Quantum\config.ini"
  echo database = farmacia>>"C:\Quantum\config.ini"
  echo allow_empty_password = false>>"C:\Quantum\config.ini"
  echo [AVISO] C:\Quantum\config.ini criado com senha vazia.
)

echo.
echo [2.5/6] Senha MySQL NAO sera exigida para COMPILAR.
echo Se a senha estiver vazia, o EXE ainda sera gerado normalmente.
echo Ao executar o sistema, ele podera pedir/configurar a senha para conectar ao MySQL.
echo.

echo [3/6] Diagnostico de bibliotecas...
python -c "import ttkbootstrap; print('ttkbootstrap OK')"
if errorlevel 1 (
    echo [ERRO] ttkbootstrap ainda nao importou. Tentando instalar novamente...
    python -m pip install --no-cache-dir "ttkbootstrap==1.20.3" --prefer-binary
    python -c "import ttkbootstrap; print('ttkbootstrap OK')"
    if errorlevel 1 (
        echo [ERRO] ttkbootstrap nao instalou no Python atual.
        pause
        exit /b 1
    )
)

python -c "import psutil; print('psutil OK')"
python -c "import mysql.connector; print('mysql.connector', mysql.connector.__version__)"
python -c "import mysql.connector.plugins.mysql_native_password; print('mysql_native_password OK')"
python -c "import mysql.connector.locales.eng.client_error; print('locale eng OK')"

echo.
echo [4/6] Limpando build e travas...
if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
if exist C:\Quantum\.pdv_quantum_ultra.lock del /f /q C:\Quantum\.pdv_quantum_ultra.lock
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

echo.
echo [5/6] Validando sintaxe antes de compilar...
python -m py_compile Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
if errorlevel 1 (
  echo.
  echo [ERRO] O codigo Python tem erro de sintaxe/indentacao.
  pause
  exit /b 1
)

echo.
echo [5/6] Compilando com todos os imports e dados...
python -m PyInstaller ^
 --onefile ^
 --noconsole ^
 --clean ^
 --name FarmaQuantum ^
 --icon farmacia_moderno.ico ^
 --hidden-import=ttkbootstrap ^
 --hidden-import=ttkbootstrap.style ^
 --hidden-import=ttkbootstrap.widgets ^
 --hidden-import=ttkbootstrap.dialogs ^
 --hidden-import=ttkbootstrap.constants ^
 --collect-submodules=ttkbootstrap ^
 --collect-data=ttkbootstrap ^
 --hidden-import=mysql.connector.locales.eng.client_error ^
 --hidden-import=mysql.connector.locales.client_error ^
 --hidden-import=mysql.connector.plugins.mysql_native_password ^
 --hidden-import=mysql.connector.plugins.caching_sha2_password ^
 --hidden-import=mysql.connector.plugins.sha256_password ^
 --hidden-import=mysql.connector.plugins.mysql_clear_password ^
 --collect-submodules=mysql.connector ^
 --collect-submodules=mysql.connector.locales ^
 --collect-submodules=mysql.connector.plugins ^
 --collect-data=mysql.connector ^
 --copy-metadata=mysql-connector-python ^
 Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py

if errorlevel 1 (
  echo.
  echo [ERRO] Falha na compilacao.
  pause
  exit /b 1
)

echo.
echo [6/6] Finalizado.
echo EXE gerado em:
echo %~dp0dist\FarmaQuantum.exe
echo.
echo OBS: A senha vazia NAO bloqueou a compilacao.
echo Se o sistema precisar conectar ao MySQL, configure depois em C:\Quantum\config.ini.
echo.
pause
