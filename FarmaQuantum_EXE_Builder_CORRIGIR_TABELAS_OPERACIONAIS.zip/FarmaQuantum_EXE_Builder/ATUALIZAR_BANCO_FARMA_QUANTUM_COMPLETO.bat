@echo off
chcp 65001 >nul
cd /d "%~dp0"
title ATUALIZAR BANCO FARMA QUANTUM COMPLETO - LOGIN CORRIGIDO

echo ============================================================
echo   ATUALIZAR BANCO FARMA QUANTUM COMPLETO
echo   LOGIN CORRIGIDO / ROOT FALLBACK / SEM MYSQL.EXE
echo ============================================================
echo.
echo Este atualizador corrige:
echo - produtos.preco
echo - tabelas de tamanhos
echo - salvamento de tamanhos cadastrados
echo - usuarios.password_hash
echo - notas/lote/validade/vendas/itens
echo.
echo Ele NAO apaga dados.
echo.
echo IMPORTANTE:
echo Se o usuario atual do config.ini falhar, o script vai pedir:
echo 1) os dados corretos do usuario do sistema
echo 2) se ainda falhar, um usuario administrador/root para liberar o banco
echo.

python -m pip install "mysql-connector-python==8.4.0" --prefer-binary >nul 2>&1

python ATUALIZAR_BANCO_FARMA_QUANTUM_COMPLETO.py
if errorlevel 1 (
    echo.
    echo [ERRO] Falha ao atualizar banco.
    echo Confira a senha do MySQL ou tente informar root quando o script pedir.
    pause
    exit /b 1
)

echo.
echo [OK] Banco atualizado com sucesso.
pause
