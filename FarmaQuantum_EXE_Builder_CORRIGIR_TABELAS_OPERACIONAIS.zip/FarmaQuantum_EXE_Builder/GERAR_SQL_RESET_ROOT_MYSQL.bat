@echo off
chcp 65001 >nul
cd /d "%~dp0"
title GERAR SQL RESET ROOT MYSQL - FARMA QUANTUM

echo ============================================================
echo   GERAR SQL PARA RESETAR ROOT MYSQL
echo ============================================================
echo.
echo Use somente se voce NAO lembra a senha do root/admin.
echo Este BAT gera um arquivo SQL para redefinir root.
echo Voce ainda precisara usar o procedimento do MySQL Installer
echo ou iniciar o mysqld com --init-file.
echo.

set /p NOVA=Nova senha para root: 
if "%NOVA%"=="" (
    echo [ERRO] Senha vazia nao permitida.
    pause
    exit /b 1
)

(
echo ALTER USER 'root'@'localhost' IDENTIFIED BY '%NOVA%';
echo ALTER USER 'root'@'127.0.0.1' IDENTIFIED BY '%NOVA%';
echo FLUSH PRIVILEGES;
) > RESET_ROOT_MYSQL.sql

echo.
echo Arquivo gerado:
echo %~dp0RESET_ROOT_MYSQL.sql
echo.
echo Caminho recomendado:
echo 1. Abra MySQL Installer.
echo 2. Reconfigure o MySQL Server.
echo 3. Defina uma nova senha root.
echo.
echo Alternativa avançada:
echo iniciar mysqld com --init-file="%~dp0RESET_ROOT_MYSQL.sql"
echo.
pause
