# -*- coding: utf-8 -*-
"""
FARMA QUANTUM - Diagnóstico e recuperação de senha/permissão MySQL

Objetivo:
- Verificar qual usuário/senha realmente conecta.
- Se root/admin conectar, recriar/liberar o usuário do sistema.
- Atualizar C:\Quantum\config.ini com os dados corretos.
- Não apaga banco e não apaga dados.

Uso:
    python RECUPERAR_ACESSO_MYSQL_FARMA.py
"""

import sys
import getpass
import configparser
from pathlib import Path

try:
    import mysql.connector
except Exception:
    print("[ERRO] mysql-connector-python não instalado.")
    print("Execute: python -m pip install mysql-connector-python==8.4.0")
    sys.exit(1)

CONFIG_PATH = Path(r"C:\Quantum\config.ini")

def log(msg):
    print("[MYSQL-RECOVERY]", msg)

def qident(v):
    return "`" + str(v).replace("`", "``") + "`"

def qstr(v):
    return "'" + str(v).replace("\\", "\\\\").replace("'", "''") + "'"

def load_cfg():
    cfg = {
        "host": "127.0.0.1",
        "port": "3306",
        "user": "usuario",
        "password": "",
        "database": "farmacia",
    }
    if CONFIG_PATH.exists():
        cp = configparser.ConfigParser()
        cp.read(str(CONFIG_PATH), encoding="utf-8")
        if cp.has_section("mysql"):
            for k in cfg:
                cfg[k] = cp.get("mysql", k, fallback=cfg[k]).strip()
    return cfg

def save_cfg(cfg):
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    cp = configparser.ConfigParser()
    cp["mysql"] = {
        "host": cfg["host"],
        "port": str(cfg["port"]),
        "user": cfg["user"],
        "password": cfg["password"],
        "database": cfg["database"],
        "allow_empty_password": "false",
    }
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        cp.write(f)
    log(f"config.ini salvo em {CONFIG_PATH}")

def test_conn(host, port, user, password, database=None):
    try:
        params = {
            "host": host,
            "port": int(port),
            "user": user,
            "password": password,
            "use_pure": True,
            "autocommit": True,
            "connect_timeout": 10,
        }
        if database:
            params["database"] = database
        conn = mysql.connector.connect(**params)
        cur = conn.cursor()
        cur.execute("SELECT VERSION()")
        version = cur.fetchone()[0]
        cur.close()
        conn.close()
        return True, f"Conectou. MySQL versão: {version}"
    except Exception as e:
        return False, str(e)

def create_schema_min(cfg):
    conn = mysql.connector.connect(
        host=cfg["host"], port=int(cfg["port"]), user=cfg["user"],
        password=cfg["password"], database=cfg["database"],
        use_pure=True, autocommit=True, connect_timeout=10,
    )
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(120) UNIQUE,
            usuario VARCHAR(120),
            nome VARCHAR(255),
            password VARCHAR(255),
            password_hash VARCHAR(255),
            senha VARCHAR(255),
            nivel VARCHAR(80),
            nivel_acesso VARCHAR(80),
            permissoes LONGTEXT,
            vinculos LONGTEXT,
            ativo TINYINT DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS produtos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            codigo VARCHAR(80),
            nome VARCHAR(255),
            descricao VARCHAR(255),
            preco DECIMAL(15,2) DEFAULT 0,
            preco_venda DECIMAL(15,2) DEFAULT 0,
            preco_custo DECIMAL(15,2) DEFAULT 0,
            estoque DECIMAL(15,3) DEFAULT 0,
            tamanho VARCHAR(120),
            tamanho_id INT NULL,
            lote VARCHAR(120),
            validade DATE NULL,
            ativo TINYINT DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS tamanhos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            descricao VARCHAR(255),
            ordem INT DEFAULT 0,
            ativo TINYINT DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS produto_tamanhos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            produto_id INT,
            tamanho_id INT,
            tamanho VARCHAR(120),
            estoque DECIMAL(15,3) DEFAULT 0,
            preco DECIMAL(15,2) DEFAULT 0,
            preco_venda DECIMAL(15,2) DEFAULT 0,
            ativo TINYINT DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """)
    cur.close()
    conn.close()

def authorize_user_with_admin(host, port, admin_user, admin_pass, sys_user, sys_pass, database):
    conn = mysql.connector.connect(
        host=host, port=int(port), user=admin_user, password=admin_pass,
        use_pure=True, autocommit=True, connect_timeout=10,
    )
    cur = conn.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS {qident(database)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")

    for h in ["localhost", "127.0.0.1", "%"]:
        try:
            cur.execute(f"CREATE USER IF NOT EXISTS {qstr(sys_user)}@{qstr(h)} IDENTIFIED BY {qstr(sys_pass)}")
        except Exception as e:
            log(f"Aviso CREATE USER {sys_user}@{h}: {e}")
        try:
            cur.execute(f"ALTER USER {qstr(sys_user)}@{qstr(h)} IDENTIFIED BY {qstr(sys_pass)}")
        except Exception as e:
            log(f"Aviso ALTER USER {sys_user}@{h}: {e}")
        try:
            cur.execute(f"GRANT ALL PRIVILEGES ON {qident(database)}.* TO {qstr(sys_user)}@{qstr(h)}")
        except Exception as e:
            log(f"Aviso GRANT {sys_user}@{h}: {e}")

    cur.execute("FLUSH PRIVILEGES")
    cur.close()
    conn.close()

def main():
    cfg = load_cfg()

    print("=" * 70)
    print(" FARMA QUANTUM - RECUPERAR ACESSO MYSQL")
    print("=" * 70)
    print()
    print("Config atual:")
    print("Host:", cfg["host"])
    print("Porta:", cfg["port"])
    print("Usuário:", cfg["user"])
    print("Banco:", cfg["database"])
    print("Senha:", "PREENCHIDA" if cfg["password"] else "VAZIA")
    print()

    ok, msg = test_conn(cfg["host"], cfg["port"], cfg["user"], cfg["password"], None)
    if ok:
        print("[OK]", msg)
        save_cfg(cfg)
        try:
            # garante banco e estrutura mínima
            admin_cfg = dict(cfg)
            conn = mysql.connector.connect(host=cfg["host"], port=int(cfg["port"]), user=cfg["user"], password=cfg["password"], use_pure=True, autocommit=True)
            cur = conn.cursor()
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {qident(cfg['database'])} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            cur.close()
            conn.close()
            create_schema_min(cfg)
            print("[OK] Estrutura mínima conferida.")
        except Exception as e:
            print("[AVISO] Conectou, mas não conseguiu criar/conferir estrutura:", e)
        return

    print("[FALHOU] Usuário atual não conectou:", msg)
    print()
    print("Escolha uma opção:")
    print("1 - Digitar novamente usuário/senha do sistema")
    print("2 - Usar root/admin para recriar/liberar o usuário do sistema")
    print("3 - Sair")
    op = input("Opção [2]: ").strip() or "2"

    if op == "1":
        cfg["host"] = input(f"Host [{cfg['host']}]: ").strip() or cfg["host"]
        cfg["port"] = input(f"Porta [{cfg['port']}]: ").strip() or cfg["port"]
        cfg["user"] = input(f"Usuário [{cfg['user']}]: ").strip() or cfg["user"]
        cfg["database"] = input(f"Banco [{cfg['database']}]: ").strip() or cfg["database"]
        cfg["password"] = getpass.getpass("Senha: ")
        ok, msg = test_conn(cfg["host"], cfg["port"], cfg["user"], cfg["password"], None)
        if not ok:
            print("[ERRO] Ainda não conectou:", msg)
            print("Execute novamente e use a opção 2 com root/admin.")
            sys.exit(1)
        save_cfg(cfg)
        print("[OK] Configuração corrigida.")
        return

    if op == "2":
        print()
        cfg["host"] = input(f"Host MySQL [{cfg['host']}]: ").strip() or cfg["host"]
        cfg["port"] = input(f"Porta [{cfg['port']}]: ").strip() or cfg["port"]
        cfg["database"] = input(f"Banco do sistema [{cfg['database']}]: ").strip() or cfg["database"]
        sys_user = input(f"Usuário que o sistema vai usar [{cfg['user']}]: ").strip() or cfg["user"]
        sys_pass = getpass.getpass("Nova senha para esse usuário do sistema: ")
        if not sys_pass:
            print("[ERRO] A senha do usuário do sistema não pode ficar vazia.")
            sys.exit(1)

        admin_user = input("Usuário administrador MySQL [root]: ").strip() or "root"
        admin_pass = getpass.getpass("Senha do administrador/root: ")

        try:
            authorize_user_with_admin(cfg["host"], cfg["port"], admin_user, admin_pass, sys_user, sys_pass, cfg["database"])
        except Exception as e:
            print("[ERRO] Root/admin também não foi aceito ou não tem permissão:", e)
            print()
            print("Solução: redefina a senha do root pelo MySQL Installer ou MySQL Workbench.")
            sys.exit(1)

        cfg["user"] = sys_user
        cfg["password"] = sys_pass
        ok, msg = test_conn(cfg["host"], cfg["port"], cfg["user"], cfg["password"], cfg["database"])
        if not ok:
            print("[ERRO] Usuário criado/liberado, mas o teste final falhou:", msg)
            sys.exit(1)

        save_cfg(cfg)
        print("[OK] Usuário liberado e config.ini atualizado.")
        try:
            create_schema_min(cfg)
            print("[OK] Estrutura mínima conferida.")
        except Exception as e:
            print("[AVISO] Falha ao conferir estrutura mínima:", e)
        return

    print("Cancelado.")

if __name__ == "__main__":
    main()
