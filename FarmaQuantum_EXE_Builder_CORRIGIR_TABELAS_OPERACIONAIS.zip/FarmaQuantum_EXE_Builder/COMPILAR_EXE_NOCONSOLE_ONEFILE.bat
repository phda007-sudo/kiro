@echo off
REM FARMA QUANTUM CHECK MYSQL CONNECTOR VERSION
python -c "import mysql.connector; print('[MYSQL CONNECTOR]', mysql.connector.__version__)"
REM FARMA QUANTUM FIX LOCK DEFINITIVO
if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
if exist C:\Quantum\.pdv_quantum_ultra.lock del /f /q C:\Quantum\.pdv_quantum_ultra.lock
if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

cls
echo ============================================================
echo   FARMA QUANTUM - GERAR EXE ONEFILE NOCONSOLE
echo   Icone: farmacia_moderno.ico
echo   Entrada: ^
 --hidden-import=mysql.connector.locales.eng.client_error ^
 --hidden-import=mysql.connector.locales.client_error ^
 --collect-submodules=mysql.connector ^
 --collect-submodules=mysql.connector.locales ^
 --collect-data=mysql.connector ^
 --hidden-import=mysql.connector.plugins.mysql_native_password ^
 --hidden-import=mysql.connector.plugins.caching_sha2_password ^
 --hidden-import=mysql.connector.plugins.sha256_password ^
 --hidden-import=mysql.connector.plugins.mysql_clear_password ^
 --collect-submodules=mysql.connector.plugins ^
 --hidden-import=ttkbootstrap ^
 --hidden-import=ttkbootstrap.style ^
 --hidden-import=ttkbootstrap.widgets ^
 --hidden-import=ttkbootstrap.dialogs ^
 --hidden-import=ttkbootstrap.constants ^
 --hidden-import=ttkbootstrap.icons ^
 --collect-submodules=ttkbootstrap ^
 --collect-data=ttkbootstrap Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
echo ============================================================
echo.
echo Se der erro de psutil/MSVC, execute CORRIGIR_ERRO_PSUTIL_SEM_MSVC.bat

cd /d "%~dp0"

set "APP_NAME=FarmaQuantum"
set "MAIN_PY=Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py"
set "ICO=farmacia_moderno.ico"
set "RUNTIME_DIR=C:\ProgramData\FarmaQuantumRuntime"

if not exist "%MAIN_PY%" (
    echo [ERRO] Arquivo principal nao encontrado: %MAIN_PY%
    pause
    exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
    echo [ERRO] Python nao encontrado no PATH.
    echo Instale o Python 3.11 e marque Add Python to PATH.
    pause
    exit /b 1
)

echo [1/5] Atualizando pip, setuptools e wheel...
python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto erro

echo.
echo [2/5] Instalando bibliotecas principais...
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [AVISO] Alguma dependencia pode ter falhado. Tentando continuar mesmo assim...
)

echo.
echo [3/5] Limpando builds antigos...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "%APP_NAME%.spec" del /q "%APP_NAME%.spec"
if not exist "%RUNTIME_DIR%" mkdir "%RUNTIME_DIR%" >nul 2>nul

echo.
echo [4/5] Compilando EXE onefile sem console...
python -m PyInstaller ^
 --noconfirm ^
 --clean ^
 --onefile ^
 --noconsole ^
 --name "%APP_NAME%" ^
 --icon "%ICO%" ^
 --runtime-tmpdir "%RUNTIME_DIR%" ^
 --add-data "%ICO%;." ^
 --hidden-import tkinter ^
 --hidden-import tkinter.ttk ^
 --hidden-import ttkbootstrap ^
 --hidden-import PIL ^
 --hidden-import PIL.Image ^
 --hidden-import mysql.connector ^
 --hidden-import reportlab ^
 --hidden-import fpdf ^
 --hidden-import openpyxl ^
 --hidden-import psutil ^
 --hidden-import serial ^
 --hidden-import bleak ^
 --hidden-import qrcode ^
 --hidden-import pyttsx3 ^
 --hidden-import win32api ^
 --hidden-import win32print ^
 --collect-all ttkbootstrap ^
 --collect-all PIL ^
 --collect-all reportlab ^
 --collect-all openpyxl ^
 --collect-all qrcode ^
 "%MAIN_PY%"

if errorlevel 1 goto erro

echo.
echo [5/5] Finalizado.
echo EXE gerado em: dist\%APP_NAME%.exe
echo.
if exist "dist\%APP_NAME%.exe" (
    explorer "%cd%\dist"
)
pause
exit /b 0

:erro
echo.
echo ============================================================
echo   FALHA NA COMPILACAO
echo ============================================================
echo Verifique as mensagens acima.
echo Dicas:
echo 1. Execute este BAT como Administrador.
echo 2. Use Python 3.11 32-bit se voce ja usa o sistema em 32-bit.
echo 3. Instale manualmente: python -m pip install -r requirements.txt
echo 4. Se Bluetooth/Flask falhar, eles sao opcionais para algumas funcoes.
echo.
pause
exit /b 1
