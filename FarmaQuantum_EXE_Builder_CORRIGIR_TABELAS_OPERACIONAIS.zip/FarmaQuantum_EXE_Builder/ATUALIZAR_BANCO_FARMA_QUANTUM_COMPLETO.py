# -*- coding: utf-8 -*-
"""
FARMA QUANTUM - Atualizador robusto do banco
Corrige:
- produtos.preco
- tabelas/colunas de tamanhos
- usuarios.password_hash
- demais colunas essenciais

Não apaga dados.
"""

import sys
import getpass
import configparser
from pathlib import Path
import mysql.connector

def log(msg):
    print("[DB-UPDATE]", msg)

def q(n):
    return "`" + str(n).replace("`", "``") + "`"

def read_config():
    cfg_path = Path(r"C:\Quantum\config.ini")
    data = {
        "host": "127.0.0.1",
        "port": "3306",
        "user": "usuario",
        "password": "",
        "database": "farmacia",
    }
    if cfg_path.exists():
        cp = configparser.ConfigParser()
        cp.read(str(cfg_path), encoding="utf-8")
        if cp.has_section("mysql"):
            for k in data:
                data[k] = cp.get("mysql", k, fallback=data[k]).strip()
    return data

def save_config(cfg):
    Path(r"C:\Quantum").mkdir(parents=True, exist_ok=True)
    cp = configparser.ConfigParser()
    cp["mysql"] = {
        "host": cfg["host"],
        "port": str(cfg["port"]),
        "user": cfg["user"],
        "password": cfg["password"],
        "database": cfg["database"],
        "allow_empty_password": "false",
    }
    with open(r"C:\Quantum\config.ini", "w", encoding="utf-8") as f:
        cp.write(f)
    log(r"config.ini atualizado em C:\Quantum\config.ini")

def connect_no_db(cfg):
    return mysql.connector.connect(
        host=cfg["host"],
        port=int(cfg["port"]),
        user=cfg["user"],
        password=cfg["password"],
        use_pure=True,
        autocommit=True,
        connect_timeout=15,
    )

def connect_db(cfg):
    return mysql.connector.connect(
        host=cfg["host"],
        port=int(cfg["port"]),
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        use_pure=True,
        autocommit=True,
        connect_timeout=15,
    )

def try_connect(cfg):
    try:
        c = connect_no_db(cfg)
        c.close()
        return True, None
    except Exception as e:
        return False, e

def ask_normal_credentials(cfg):
    print()
    print("A conexão com o usuário atual falhou.")
    print("Informe os dados corretos do usuário que o sistema deve usar.")
    print("Deixe em branco para manter o valor atual entre colchetes.")
    host = input(f"Host [{cfg['host']}]: ").strip() or cfg["host"]
    port = input(f"Porta [{cfg['port']}]: ").strip() or cfg["port"]
    user = input(f"Usuário [{cfg['user']}]: ").strip() or cfg["user"]
    database = input(f"Banco [{cfg['database']}]: ").strip() or cfg["database"]
    password = getpass.getpass("Senha do usuário MySQL: ")
    cfg.update({"host": host, "port": port, "user": user, "password": password, "database": database})
    return cfg

def authorize_with_admin(cfg):
    print()
    print("O usuário informado ainda não conectou.")
    print("Agora informe um usuário ADMINISTRADOR do MySQL para criar/liberar o banco e o usuário.")
    print("Normalmente: root")
    admin_user = input("Usuário administrador [root]: ").strip() or "root"
    admin_pass = getpass.getpass("Senha do administrador MySQL: ")
    try:
        admin_cfg = dict(cfg)
        admin_cfg["user"] = admin_user
        admin_cfg["password"] = admin_pass
        conn = connect_no_db(admin_cfg)
        cur = conn.cursor()

        cur.execute(f"CREATE DATABASE IF NOT EXISTS {q(cfg['database'])} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")

        def s(v):
            return "'" + str(v).replace("\\", "\\\\").replace("'", "''") + "'"

        # Cria/libera usuario nos hosts comuns
        for host_alvo in ["localhost", "127.0.0.1", "%"]:
            try:
                cur.execute(f"CREATE USER IF NOT EXISTS {s(cfg['user'])}@{s(host_alvo)} IDENTIFIED BY {s(cfg['password'])}")
            except Exception as e:
                log(f"aviso CREATE USER {cfg['user']}@{host_alvo}: {e}")
            try:
                cur.execute(f"ALTER USER {s(cfg['user'])}@{s(host_alvo)} IDENTIFIED BY {s(cfg['password'])}")
            except Exception as e:
                log(f"aviso ALTER USER {cfg['user']}@{host_alvo}: {e}")
            try:
                cur.execute(f"GRANT ALL PRIVILEGES ON {q(cfg['database'])}.* TO {s(cfg['user'])}@{s(host_alvo)}")
            except Exception as e:
                log(f"aviso GRANT {cfg['user']}@{host_alvo}: {e}")

        cur.execute("FLUSH PRIVILEGES")
        cur.close()
        conn.close()
        log("Banco/usuário criados ou autorizados com administrador.")
        return True
    except Exception as e:
        log(f"falha ao autorizar com administrador: {e}")
        return False

cfg = read_config()
if len(sys.argv) >= 6:
    cfg.update({
        "host": sys.argv[1].strip(),
        "port": sys.argv[2].strip(),
        "user": sys.argv[3].strip(),
        "password": sys.argv[4],
        "database": sys.argv[5].strip(),
    })

print("Config atual:")
print("Host:", cfg["host"])
print("Porta:", cfg["port"])
print("Usuário:", cfg["user"])
print("Banco:", cfg["database"])
print("Senha:", "PREENCHIDA" if cfg["password"] else "VAZIA")
print()

ok, err = try_connect(cfg)
if not ok:
    log(f"conexão inicial falhou: {err}")
    cfg = ask_normal_credentials(cfg)
    ok, err = try_connect(cfg)
    if not ok:
        log(f"conexão com usuário informado falhou: {err}")
        if not authorize_with_admin(cfg):
            print()
            print("[ERRO] Não foi possível conectar nem autorizar o usuário.")
            print("Confira a senha do MySQL ou execute como root/administrador.")
            sys.exit(1)
        ok, err = try_connect(cfg)
        if not ok:
            print("[ERRO] Usuário autorizado, mas teste final falhou:", err)
            sys.exit(1)

save_config(cfg)

# Cria banco
conn0 = connect_no_db(cfg)
cur0 = conn0.cursor()
cur0.execute(f"CREATE DATABASE IF NOT EXISTS {q(cfg['database'])} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
cur0.close()
conn0.close()

conn = connect_db(cfg)
cur = conn.cursor()

def exec_safe(sql, desc=""):
    try:
        cur.execute(sql)
        if desc:
            log("OK: " + desc)
        return True
    except Exception as e:
        log("AVISO " + desc + ": " + str(e))
        return False

def cols(table):
    try:
        cur.execute(f"SHOW COLUMNS FROM {q(table)}")
        return {r[0].lower() for r in cur.fetchall()}
    except Exception:
        return set()

def add_col(table, col, ddl):
    if col.lower() not in cols(table):
        exec_safe(f"ALTER TABLE {q(table)} ADD COLUMN {ddl}", f"{table}.{col}")

def ensure_table(table, ddl):
    exec_safe(ddl, "tabela " + table)

# USUARIOS
ensure_table("usuarios", """
CREATE TABLE IF NOT EXISTS usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(120) UNIQUE,
 usuario VARCHAR(120),
 nome VARCHAR(255),
 password VARCHAR(255),
 password_hash VARCHAR(255),
 senha VARCHAR(255),
 nivel VARCHAR(80),
 nivel_acesso VARCHAR(80),
 permissoes LONGTEXT,
 vinculos LONGTEXT,
 ativo TINYINT DEFAULT 1,
 bloqueado TINYINT DEFAULT 0,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 atualizado_em TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
"username":"username VARCHAR(120)", "usuario":"usuario VARCHAR(120)", "nome":"nome VARCHAR(255)",
"password":"password VARCHAR(255)", "password_hash":"password_hash VARCHAR(255)", "senha":"senha VARCHAR(255)",
"nivel":"nivel VARCHAR(80)", "nivel_acesso":"nivel_acesso VARCHAR(80)", "permissoes":"permissoes LONGTEXT",
"vinculos":"vinculos LONGTEXT", "ativo":"ativo TINYINT DEFAULT 1", "bloqueado":"bloqueado TINYINT DEFAULT 0",
}.items(): add_col("usuarios", col, ddl)

# PRODUTOS + PRECO
ensure_table("produtos", """
CREATE TABLE IF NOT EXISTS produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 codigo VARCHAR(80),
 codigo_barras VARCHAR(80),
 nome VARCHAR(255),
 descricao VARCHAR(255),
 categoria VARCHAR(120),
 grupo VARCHAR(120),
 unidade VARCHAR(40),
 tamanho VARCHAR(120),
 tamanho_id INT NULL,
 estoque DECIMAL(15,3) DEFAULT 0,
 estoque_minimo DECIMAL(15,3) DEFAULT 0,
 preco DECIMAL(15,2) DEFAULT 0,
 preco_custo DECIMAL(15,2) DEFAULT 0,
 preco_compra DECIMAL(15,2) DEFAULT 0,
 preco_venda DECIMAL(15,2) DEFAULT 0,
 valor DECIMAL(15,2) DEFAULT 0,
 valor_venda DECIMAL(15,2) DEFAULT 0,
 custo DECIMAL(15,2) DEFAULT 0,
 lote VARCHAR(120),
 validade DATE NULL,
 data_validade DATE NULL,
 controlar_lote_validade TINYINT DEFAULT 0,
 ativo TINYINT DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 atualizado_em TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
"codigo":"codigo VARCHAR(80)", "codigo_barras":"codigo_barras VARCHAR(80)", "nome":"nome VARCHAR(255)",
"descricao":"descricao VARCHAR(255)", "categoria":"categoria VARCHAR(120)", "grupo":"grupo VARCHAR(120)",
"unidade":"unidade VARCHAR(40)", "tamanho":"tamanho VARCHAR(120)", "tamanho_id":"tamanho_id INT NULL",
"estoque":"estoque DECIMAL(15,3) DEFAULT 0", "estoque_minimo":"estoque_minimo DECIMAL(15,3) DEFAULT 0",
"preco":"preco DECIMAL(15,2) DEFAULT 0", "preco_custo":"preco_custo DECIMAL(15,2) DEFAULT 0",
"preco_compra":"preco_compra DECIMAL(15,2) DEFAULT 0", "preco_venda":"preco_venda DECIMAL(15,2) DEFAULT 0",
"valor":"valor DECIMAL(15,2) DEFAULT 0", "valor_venda":"valor_venda DECIMAL(15,2) DEFAULT 0",
"custo":"custo DECIMAL(15,2) DEFAULT 0", "lote":"lote VARCHAR(120)", "validade":"validade DATE NULL",
"data_validade":"data_validade DATE NULL", "controlar_lote_validade":"controlar_lote_validade TINYINT DEFAULT 0",
"ativo":"ativo TINYINT DEFAULT 1", "atualizado_em":"atualizado_em TIMESTAMP NULL DEFAULT NULL"
}.items(): add_col("produtos", col, ddl)
exec_safe("UPDATE produtos SET preco = preco_venda WHERE (preco IS NULL OR preco = 0) AND preco_venda IS NOT NULL AND preco_venda <> 0", "sync preco")
exec_safe("UPDATE produtos SET preco_venda = preco WHERE (preco_venda IS NULL OR preco_venda = 0) AND preco IS NOT NULL AND preco <> 0", "sync preco_venda")

# TAMANHOS
ensure_table("tamanhos", """
CREATE TABLE IF NOT EXISTS tamanhos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL,
 descricao VARCHAR(255),
 ordem INT DEFAULT 0,
 ativo TINYINT DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 atualizado_em TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for col, ddl in {
"nome":"nome VARCHAR(120) NOT NULL", "descricao":"descricao VARCHAR(255)", "ordem":"ordem INT DEFAULT 0",
"ativo":"ativo TINYINT DEFAULT 1", "atualizado_em":"atualizado_em TIMESTAMP NULL DEFAULT NULL"
}.items(): add_col("tamanhos", col, ddl)

ensure_table("produto_tamanhos", """
CREATE TABLE IF NOT EXISTS produto_tamanhos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 produto_id INT,
 tamanho_id INT,
 tamanho VARCHAR(120),
 codigo_barras VARCHAR(80),
 estoque DECIMAL(15,3) DEFAULT 0,
 preco DECIMAL(15,2) DEFAULT 0,
 preco_venda DECIMAL(15,2) DEFAULT 0,
 ativo TINYINT DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
ensure_table("tamanhos_produtos", """
CREATE TABLE IF NOT EXISTS tamanhos_produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 produto_id INT,
 nome VARCHAR(120),
 tamanho VARCHAR(120),
 descricao VARCHAR(255),
 estoque DECIMAL(15,3) DEFAULT 0,
 preco DECIMAL(15,2) DEFAULT 0,
 preco_venda DECIMAL(15,2) DEFAULT 0,
 ativo TINYINT DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
""")
for table in ["produto_tamanhos", "tamanhos_produtos"]:
    for col, ddl in {
        "produto_id":"produto_id INT", "tamanho_id":"tamanho_id INT", "nome":"nome VARCHAR(120)",
        "tamanho":"tamanho VARCHAR(120)", "descricao":"descricao VARCHAR(255)",
        "codigo_barras":"codigo_barras VARCHAR(80)", "estoque":"estoque DECIMAL(15,3) DEFAULT 0",
        "preco":"preco DECIMAL(15,2) DEFAULT 0", "preco_venda":"preco_venda DECIMAL(15,2) DEFAULT 0",
        "ativo":"ativo TINYINT DEFAULT 1"
    }.items():
        add_col(table, col, ddl)

for sql in [
"INSERT IGNORE INTO tamanhos (id,nome,descricao,ordem,ativo) VALUES (1,'PP','Extra pequeno',1,1)",
"INSERT IGNORE INTO tamanhos (id,nome,descricao,ordem,ativo) VALUES (2,'P','Pequeno',2,1)",
"INSERT IGNORE INTO tamanhos (id,nome,descricao,ordem,ativo) VALUES (3,'M','Médio',3,1)",
"INSERT IGNORE INTO tamanhos (id,nome,descricao,ordem,ativo) VALUES (4,'G','Grande',4,1)",
"INSERT IGNORE INTO tamanhos (id,nome,descricao,ordem,ativo) VALUES (5,'GG','Extra grande',5,1)",
"INSERT IGNORE INTO tamanhos (id,nome,descricao,ordem,ativo) VALUES (6,'Único','Tamanho único',6,1)",
]:
    exec_safe(sql, "tamanho padrão")

# OUTRAS TABELAS
table_ddls = {
"clientes": "CREATE TABLE IF NOT EXISTS clientes (id INT AUTO_INCREMENT PRIMARY KEY, codigo VARCHAR(80), nome VARCHAR(255), cpf VARCHAR(40), cnpj VARCHAR(40), telefone VARCHAR(80), whatsapp VARCHAR(80), endereco VARCHAR(255), bairro VARCHAR(120), observacao TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"fornecedores": "CREATE TABLE IF NOT EXISTS fornecedores (id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(255), cnpj VARCHAR(40), telefone VARCHAR(80), email VARCHAR(160), endereco VARCHAR(255), observacao TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"vendas": "CREATE TABLE IF NOT EXISTS vendas (id INT AUTO_INCREMENT PRIMARY KEY, numero VARCHAR(80), cupom VARCHAR(80), cliente_id INT NULL, cliente_nome VARCHAR(255), data_venda DATETIME DEFAULT CURRENT_TIMESTAMP, subtotal DECIMAL(15,2) DEFAULT 0, total DECIMAL(15,2) DEFAULT 0, desconto DECIMAL(15,2) DEFAULT 0, acrescimo DECIMAL(15,2) DEFAULT 0, forma_pagamento VARCHAR(120), usuario VARCHAR(120), status VARCHAR(80) DEFAULT 'FINALIZADA') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"vendas_itens": "CREATE TABLE IF NOT EXISTS vendas_itens (id INT AUTO_INCREMENT PRIMARY KEY, venda_id INT, produto_id INT, produto_nome VARCHAR(255), quantidade DECIMAL(15,3) DEFAULT 0, valor_unitario DECIMAL(15,2) DEFAULT 0, preco DECIMAL(15,2) DEFAULT 0, valor_total DECIMAL(15,2) DEFAULT 0, tamanho VARCHAR(120), tamanho_id INT NULL, lote VARCHAR(120), validade DATE NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"notas_entrada": "CREATE TABLE IF NOT EXISTS notas_entrada (id INT AUTO_INCREMENT PRIMARY KEY, numero_nota VARCHAR(120), fornecedor VARCHAR(255), data_entrada DATE NULL, produto_id INT NULL, produto_nome VARCHAR(255), quantidade DECIMAL(15,3) DEFAULT 0, preco DECIMAL(15,2) DEFAULT 0, custo DECIMAL(15,2) DEFAULT 0, lote VARCHAR(120), validade DATE NULL, controlar_lote_validade TINYINT DEFAULT 0, valor_total DECIMAL(15,2) DEFAULT 0, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"estoque_lotes": "CREATE TABLE IF NOT EXISTS estoque_lotes (id INT AUTO_INCREMENT PRIMARY KEY, produto_id INT, produto_nome VARCHAR(255), lote VARCHAR(120), validade DATE NULL, quantidade DECIMAL(15,3) DEFAULT 0, alerta_15_dias TINYINT DEFAULT 1, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"tratamentos_continuos": "CREATE TABLE IF NOT EXISTS tratamentos_continuos (id INT AUTO_INCREMENT PRIMARY KEY, cliente_nome VARCHAR(255), telefone VARCHAR(80), medicamento VARCHAR(255), dose VARCHAR(255), consumo_dia DECIMAL(15,3) DEFAULT 1, quantidade_comprada DECIMAL(15,3) DEFAULT 0, data_compra DATE NULL, data_previsao_fim DATE NULL, data_lembrete DATE NULL, ativo TINYINT DEFAULT 1, observacao TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"prontuario_ambulatorial": "CREATE TABLE IF NOT EXISTS prontuario_ambulatorial (id INT AUTO_INCREMENT PRIMARY KEY, paciente VARCHAR(255), cpf VARCHAR(40), telefone VARCHAR(80), data_hora DATETIME DEFAULT CURRENT_TIMESTAMP, tipo_atendimento VARCHAR(120), classificacao_risco VARCHAR(120), pressao VARCHAR(40), glicemia VARCHAR(40), temperatura VARCHAR(40), queixa TEXT, anamnese TEXT, conduta TEXT, orientacoes TEXT, profissional VARCHAR(255), observacao TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"configuracoes": "CREATE TABLE IF NOT EXISTS configuracoes (chave VARCHAR(150) PRIMARY KEY, valor LONGTEXT, atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
}
for table, ddl in table_ddls.items():
    ensure_table(table, ddl)

for t, cmap in {
"vendas_itens":{"preco":"preco DECIMAL(15,2) DEFAULT 0","tamanho":"tamanho VARCHAR(120)","tamanho_id":"tamanho_id INT NULL"},
"notas_entrada":{"preco":"preco DECIMAL(15,2) DEFAULT 0","custo":"custo DECIMAL(15,2) DEFAULT 0","lote":"lote VARCHAR(120)","validade":"validade DATE NULL","controlar_lote_validade":"controlar_lote_validade TINYINT DEFAULT 0"},
}.items():
    for col, ddl in cmap.items():
        add_col(t, col, ddl)

exec_safe("INSERT IGNORE INTO configuracoes (chave, valor) VALUES ('alerta_validade_dias','15')", "config alerta")
exec_safe("INSERT INTO configuracoes (chave, valor) VALUES ('schema_farma_quantum_ultima_correcao', NOW()) ON DUPLICATE KEY UPDATE valor = NOW()", "marca versão")

cur.close()
conn.close()
log("ATUALIZAÇÃO CONCLUÍDA COM SUCESSO.")
print()
print("Agora abra o Farma Quantum novamente.")
