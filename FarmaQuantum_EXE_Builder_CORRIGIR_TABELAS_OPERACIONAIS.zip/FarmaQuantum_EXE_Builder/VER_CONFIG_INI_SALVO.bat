@echo off
chcp 65001 >nul
cd /d "%~dp0"
title VER CONFIG.INI - FARMA QUANTUM

echo ============================================================
echo   VERIFICAR CONFIG.INI - FARMA QUANTUM
echo ============================================================
echo.

if exist "C:\Quantum\config.ini" (
    echo [C:\Quantum\config.ini]
    type "C:\Quantum\config.ini"
    echo.
) else (
    echo [AVISO] C:\Quantum\config.ini nao encontrado.
)

if exist "%~dp0config.ini" (
    echo.
    echo [%~dp0config.ini]
    type "%~dp0config.ini"
    echo.
)

if exist "%~dp0dist\config.ini" (
    echo.
    echo [%~dp0dist\config.ini]
    type "%~dp0dist\config.ini"
    echo.
)

echo.
pause
