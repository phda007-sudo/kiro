@echo off
chcp 65001 >nul
cd /d "%~dp0"
title LIMPAR TRAVA DEFINITIVA - FARMA QUANTUM

echo ============================================================
echo   LIMPAR TRAVA DEFINITIVA - FARMA QUANTUM
echo ============================================================
echo.

echo [1/3] Removendo arquivos de trava conhecidos...
if exist ".pdv_quantum_ultra.lock" del /f /q ".pdv_quantum_ultra.lock"
if exist "dist\.pdv_quantum_ultra.lock" del /f /q "dist\.pdv_quantum_ultra.lock"
if exist "C:\Quantum\.pdv_quantum_ultra.lock" del /f /q "C:\Quantum\.pdv_quantum_ultra.lock"
if exist "%~dp0.pdv_quantum_ultra.lock" del /f /q "%~dp0.pdv_quantum_ultra.lock"
if exist "%~dp0dist\.pdv_quantum_ultra.lock" del /f /q "%~dp0dist\.pdv_quantum_ultra.lock"

echo.
echo [2/3] Verificando processos antigos FarmaQuantum.exe...
tasklist | find /i "FarmaQuantum.exe" >nul
if not errorlevel 1 (
    echo Processo FarmaQuantum.exe encontrado.
    echo Se ele estiver travado/invisivel, ele sera finalizado.
    taskkill /f /im FarmaQuantum.exe
) else (
    echo Nenhum FarmaQuantum.exe antigo encontrado.
)

echo.
echo [3/3] Concluido.
echo Agora abra ou compile novamente.
echo.
pause
