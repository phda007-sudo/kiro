@echo off
chcp 65001 >nul
cd /d "%~dp0"
title DIAGNOSTICO MYSQL CONNECTOR PLUGINS - FARMA QUANTUM

echo ============================================================
echo   DIAGNOSTICO MYSQL CONNECTOR PLUGINS
echo ============================================================
echo.

python -c "import mysql.connector; print('mysql.connector:', mysql.connector.__version__)"
python -c "import mysql.connector.plugins.mysql_native_password; print('mysql_native_password: OK')"
python -c "import mysql.connector.plugins.caching_sha2_password; print('caching_sha2_password: OK')"
python -c "import mysql.connector.locales.eng.client_error; print('locale eng: OK')"

echo.
pause
