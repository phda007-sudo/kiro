@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CORRIGIR CONFIG.INI SENHA MYSQL - FARMA QUANTUM

echo ============================================================
echo   CORRIGIR CONFIG.INI - SENHA MYSQL
echo ============================================================
echo.
echo Este script corrige o erro:
echo Access denied ... using password: NO
echo.
echo Ele grava a senha em C:\Quantum\config.ini.
echo.

set /p HOST=Host MySQL [127.0.0.1]: 
if "%HOST%"=="" set "HOST=127.0.0.1"

set /p PORTA=Porta [3306]: 
if "%PORTA%"=="" set "PORTA=3306"

set /p USUARIO=Usuario MySQL [usuario]: 
if "%USUARIO%"=="" set "USUARIO=usuario"

set /p BANCO=Banco [farmacia]: 
if "%BANCO%"=="" set "BANCO=farmacia"

set /p SENHA=Senha MySQL: 

if "%SENHA%"=="" (
    echo.
    echo [ERRO] A senha ficou vazia. O sistema continuara dando using password: NO.
    echo Execute novamente e digite a senha real do usuario MySQL.
    pause
    exit /b 1
)

if not exist "C:\Quantum" mkdir "C:\Quantum"

(
echo [mysql]
echo host = %HOST%
echo port = %PORTA%
echo user = %USUARIO%
echo password = %SENHA%
echo database = %BANCO%
echo allow_empty_password = false
) > "C:\Quantum\config.ini"

echo.
echo [OK] Arquivo salvo em C:\Quantum\config.ini
echo.
type "C:\Quantum\config.ini"
echo.
pause
