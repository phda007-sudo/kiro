@echo off
chcp 65001 >nul
cd /d "%~dp0"
title RECUPERAR ACESSO MYSQL - FARMA QUANTUM

echo ============================================================
echo   RECUPERAR ACESSO MYSQL - FARMA QUANTUM
echo ============================================================
echo.
echo Use este arquivo quando:
echo - a senha nao aceita;
echo - usuario da Access denied;
echo - o atualizador nao consegue conectar;
echo - precisa recriar/liberar o usuario do sistema.
echo.
echo O script NAO apaga dados.
echo.

python -m pip install "mysql-connector-python==8.4.0" --prefer-binary >nul 2>&1
python RECUPERAR_ACESSO_MYSQL_FARMA.py

echo.
pause
