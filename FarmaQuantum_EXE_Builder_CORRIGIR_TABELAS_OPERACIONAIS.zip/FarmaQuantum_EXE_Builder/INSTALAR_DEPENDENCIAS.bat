REM FARMA QUANTUM FIX MYSQL_NATIVE_PASSWORD
@echo off
chcp 65001 >nul
cd /d "%~dp0"
title INSTALAR DEPENDENCIAS - FARMA QUANTUM - MODO ROBUSTO SEM MSVC

echo ============================================================
echo   INSTALAR DEPENDENCIAS - FARMA QUANTUM
echo   MODO ROBUSTO - SEM COMPILAR PSUTIL / SEM MSVC
echo ============================================================
echo.

set "PY=python"
%PY% --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado no PATH.
    echo Instale o Python 3.11 32-bit/64-bit e marque "Add Python to PATH".
    pause
    exit /b 1
)

echo [1/6] Atualizando pip, setuptools e wheel...
%PY% -m pip install --upgrade pip setuptools wheel --prefer-binary
echo.

echo.
echo [MYSQL] Corrigindo conector MySQL para compatibilidade com mysql_native_password...
python -m pip uninstall -y mysql-connector-python
python -m pip install --no-cache-dir "mysql-connector-python==8.4.0"
echo.

echo [2/6] Instalando dependencias principais SEM psutil...
echo      Observacao: psutil foi removido das dependencias principais
echo      porque em Python 32-bit algumas versoes tentam compilar e pedem MSVC.
%PY% -m pip install -r requirements.txt --prefer-binary --only-binary=:all:
if errorlevel 1 (
    echo.
    echo [AVISO] Alguma dependencia principal falhou usando only-binary.
    echo Tentando novamente com modo normal, exceto psutil...
    %PY% -m pip install -r requirements.txt --prefer-binary
)
echo.

echo [3/6] Tentando instalar psutil binario compativel...
echo      Se falhar, o sistema continua funcionando; apenas o monitoramento
echo      avancado de CPU/memoria fica reduzido.
%PY% -m pip install "psutil==5.9.8" --only-binary=:all: --prefer-binary
if errorlevel 1 (
    echo [AVISO] psutil nao foi instalado porque nao ha wheel pronto para este Python.
    echo [OK] O Farma Quantum possui fallback interno e pode continuar sem psutil.
) else (
    echo [OK] psutil instalado com sucesso.
)
echo.

echo [4/6] Tentando instalar dependencias opcionais restantes...
echo      Falhas aqui nao impedem a compilacao.
%PY% -m pip install -r requirements_opcionais.txt --prefer-binary
if errorlevel 1 (
    echo [AVISO] Uma ou mais dependencias opcionais falharam. Continuando...
)
echo.

echo [5/6] Conferindo PyInstaller...
%PY% -m PyInstaller --version
if errorlevel 1 (
    echo [ERRO] PyInstaller nao esta disponivel.
    pause
    exit /b 1
)
echo.

echo [6/6] Dependencias finalizadas.
echo.
echo IMPORTANTE:
echo - O erro "Microsoft Visual C++ 14.0 or greater is required" vinha do psutil.
echo - Agora o psutil nao trava mais a instalacao principal.
echo - Para Bluetooth, balanca, servidor web ou recursos extras, algumas libs opcionais
echo   podem depender do Windows, driver, versao do Python e arquitetura 32/64-bit.
echo.
pause
