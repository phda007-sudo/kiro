@echo off
chcp 65001 >nul
cd /d "%~dp0"
title ATUALIZAR BANCO COMO ROOT - FARMA QUANTUM

echo ============================================================
echo   ATUALIZAR BANCO COMO ROOT / ADMINISTRADOR
echo ============================================================
echo.
echo Use este se o usuario 'usuario' estiver dando Access denied.
echo.

set /p HOST=Host [127.0.0.1]: 
if "%HOST%"=="" set "HOST=127.0.0.1"

set /p PORTA=Porta [3306]: 
if "%PORTA%"=="" set "PORTA=3306"

set /p BANCO=Banco [farmacia]: 
if "%BANCO%"=="" set "BANCO=farmacia"

set /p USER_SYS=Usuario do sistema que sera liberado [usuario]: 
if "%USER_SYS%"=="" set "USER_SYS=usuario"

set /p SENHA_SYS=Senha que deseja para o usuario do sistema: 

echo.
echo Agora informe root/admin dentro do script Python.
echo.

python ATUALIZAR_BANCO_FARMA_QUANTUM_COMPLETO.py "%HOST%" "%PORTA%" "%USER_SYS%" "%SENHA_SYS%" "%BANCO%"

pause
