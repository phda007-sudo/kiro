@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CORRIGIR MYSQL - No localization support for language eng

echo ============================================================
echo   CORRIGIR MYSQL: No localization support for language 'eng'
echo ============================================================
echo.
echo Este erro normalmente acontece quando o MySQL foi configurado
echo com idioma antigo/invalido, por exemplo:
echo.
echo     language=eng
echo.
echo O correto e usar:
echo.
echo     lc-messages=en_US
echo.
echo Este script vai tentar localizar arquivos my.ini / my.cnf comuns
echo e criar uma copia de seguranca antes de alterar.
echo.
echo IMPORTANTE: execute como ADMINISTRADOR.
echo.

setlocal EnableDelayedExpansion

set "ACHOU=0"

for %%F in (
    "C:\ProgramData\MySQL\MySQL Server 8.0\my.ini"
    "C:\ProgramData\MySQL\MySQL Server 5.7\my.ini"
    "C:\ProgramData\MySQL\MySQL Server 5.6\my.ini"
    "C:\Program Files\MySQL\MySQL Server 8.0\my.ini"
    "C:\Program Files\MySQL\MySQL Server 5.7\my.ini"
    "C:\Program Files\MySQL\MySQL Server 5.6\my.ini"
    "C:\xampp\mysql\bin\my.ini"
    "C:\wamp64\bin\mysql\mysql8.0.31\my.ini"
    "C:\wamp64\bin\mysql\mysql5.7.36\my.ini"
    "C:\laragon\bin\mysql\mysql-8.0\my.ini"
    "C:\laragon\bin\mysql\mysql-5.7\my.ini"
) do (
    if exist %%~F (
        echo [ENCONTRADO] %%~F
        set "ACHOU=1"
        copy /Y %%~F "%%~F.bak_farmaquantum_language_eng" >nul

        powershell -NoProfile -ExecutionPolicy Bypass -Command ^
        "$p='%%~F';" ^
        "$txt=Get-Content -LiteralPath $p -Raw;" ^
        "$txt=$txt -replace '(?im)^\s*language\s*=\s*eng\s*$', 'lc-messages=en_US';" ^
        "$txt=$txt -replace '(?im)^\s*language\s*=\s*english\s*$', 'lc-messages=en_US';" ^
        "if($txt -notmatch '(?im)^\s*lc-messages\s*=') { $txt = $txt -replace '(?im)^\s*\[mysqld\]\s*$', \"[mysqld]`r`nlc-messages=en_US\" };" ^
        "Set-Content -LiteralPath $p -Value $txt -Encoding ASCII;"

        echo [OK] Arquivo ajustado e backup criado.
        echo.
    )
)

if "%ACHOU%"=="0" (
    echo [AVISO] Nao encontrei automaticamente o my.ini/my.cnf.
    echo.
    echo Abra manualmente o arquivo de configuracao do MySQL e procure por:
    echo     language=eng
    echo.
    echo Troque por:
    echo     lc-messages=en_US
    echo.
    echo Locais comuns:
    echo - C:\ProgramData\MySQL\MySQL Server 8.0\my.ini
    echo - C:\ProgramData\MySQL\MySQL Server 5.7\my.ini
    echo - C:\xampp\mysql\bin\my.ini
    echo - C:\laragon\bin\mysql\...\my.ini
    echo.
)

echo ============================================================
echo   REINICIANDO SERVICOS MYSQL, SE EXISTIREM
echo ============================================================
echo.

for %%S in (MySQL80 MySQL57 MySQL56 MySQL mysql80 mysql57 MariaDB mariadb) do (
    sc query %%S >nul 2>&1
    if not errorlevel 1 (
        echo Reiniciando servico %%S ...
        net stop %%S
        net start %%S
        echo.
    )
)

echo.
echo Finalizado.
echo Agora abra novamente o Farma Quantum e teste a conexao.
echo.
pause
