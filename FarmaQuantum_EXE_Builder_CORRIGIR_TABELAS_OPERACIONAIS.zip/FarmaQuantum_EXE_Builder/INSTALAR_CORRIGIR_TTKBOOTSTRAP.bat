@echo off
chcp 65001 >nul
cd /d "%~dp0"
title INSTALAR TTKBOOTSTRAP - FARMA QUANTUM

echo ============================================================
echo   INSTALAR / CORRIGIR TTKBOOTSTRAP
echo ============================================================
echo.

echo [1/4] Conferindo Python usado...
where python
python --version
echo.

echo [2/4] Instalando ttkbootstrap no Python atual...
python -m pip install --upgrade pip setuptools wheel --prefer-binary
python -m pip uninstall -y ttkbootstrap
python -m pip install --no-cache-dir "ttkbootstrap==1.20.3" --prefer-binary

echo.
echo [3/4] Testando import...
python -c "import ttkbootstrap; print('ttkbootstrap OK')"
if errorlevel 1 (
    echo.
    echo [ERRO] ttkbootstrap ainda nao importou.
    echo Confirme se voce esta usando o mesmo Python que compila o EXE.
    pause
    exit /b 1
)

echo.
echo [4/4] Pronto.
echo Agora compile com:
echo COMPILAR_EXE_DEFINITIVO_TUDO_CORRIGIDO.bat
echo.
pause
