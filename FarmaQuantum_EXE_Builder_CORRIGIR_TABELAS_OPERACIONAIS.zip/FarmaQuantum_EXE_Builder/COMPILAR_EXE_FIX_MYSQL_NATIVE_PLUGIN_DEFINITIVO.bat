@echo off
chcp 65001 >nul
cd /d "%~dp0"
title COMPILAR EXE - FIX MYSQL NATIVE PASSWORD PLUGIN

echo ============================================================
echo   COMPILAR EXE FARMA QUANTUM
echo   FIX MYSQL NATIVE PASSWORD PLUGIN + LOCALE ENG
echo ============================================================
echo.
echo Este compilador inclui explicitamente:
echo - mysql.connector.locales.eng.client_error
echo - mysql.connector.plugins.mysql_native_password
echo - mysql.connector.plugins.caching_sha2_password
echo - todos os submodulos mysql.connector.plugins
echo.

if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
if exist C:\Quantum\.pdv_quantum_ultra.lock del /f /q C:\Quantum\.pdv_quantum_ultra.lock

echo.
echo [INFO] Versao do mysql-connector-python instalada:
python -c "import mysql.connector; print(mysql.connector.__version__)"

echo.
echo [INFO] Testando importacao do plugin mysql_native_password no Python atual...
python -c "import mysql.connector.plugins.mysql_native_password; print('mysql_native_password OK')"
if errorlevel 1 (
    echo.
    echo [ERRO] O plugin mysql_native_password nao existe no ambiente atual.
    echo Execute primeiro:
    echo CORRIGIR_MYSQL_NATIVE_PASSWORD.bat
    pause
    exit /b 1
)

echo.
echo [INFO] Limpando build anterior...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist FarmaQuantum.spec del /f /q FarmaQuantum.spec

echo.
echo [INFO] Compilando...
python -m PyInstaller ^
 --onefile ^
 --noconsole ^
 --clean ^
 --name FarmaQuantum ^
 --icon farmacia_moderno.ico ^
 --hidden-import=mysql.connector.locales.eng.client_error ^
 --hidden-import=mysql.connector.locales.client_error ^
 --hidden-import=mysql.connector.plugins.mysql_native_password ^
 --hidden-import=mysql.connector.plugins.caching_sha2_password ^
 --hidden-import=mysql.connector.plugins.sha256_password ^
 --hidden-import=mysql.connector.plugins.mysql_clear_password ^
 --hidden-import=mysql.connector.connection ^
 --hidden-import=mysql.connector.pooling ^
 --hidden-import=mysql.connector.errorcode ^
 --collect-submodules=mysql.connector ^
 --collect-submodules=mysql.connector.locales ^
 --collect-submodules=mysql.connector.plugins ^
 --collect-data=mysql.connector ^
 --copy-metadata=mysql-connector-python ^ ^
 --hidden-import=ttkbootstrap ^
 --hidden-import=ttkbootstrap.style ^
 --hidden-import=ttkbootstrap.widgets ^
 --hidden-import=ttkbootstrap.dialogs ^
 --hidden-import=ttkbootstrap.constants ^
 --hidden-import=ttkbootstrap.icons ^
 --collect-submodules=ttkbootstrap ^
 --collect-data=ttkbootstrap
 Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py

if errorlevel 1 (
    echo.
    echo [ERRO] Falha na compilacao.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo EXE gerado com sucesso em:
echo dist\FarmaQuantum.exe
echo ============================================================
echo.
pause
