@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CORRIGIR TABELAS OPERACIONAIS - FARMA QUANTUM

echo ============================================================
echo   CORRIGIR TABELAS OPERACIONAIS - FARMA QUANTUM
echo ============================================================
echo.
echo Corrige erros:
echo - comandas nao existe
echo - entregadores nao existe
echo - servicos nao existe
echo - bairros nao existe
echo - cartoes nao existe
echo - vendedores nao existe
echo - customers sem cpf
echo - tamanhos sem sigla
echo.
echo Nao apaga dados.
echo.

python -m pip install "mysql-connector-python==8.4.0" --prefer-binary >nul 2>&1
python CORRIGIR_TABELAS_OPERACIONAIS_FARMA.py

echo.
pause
