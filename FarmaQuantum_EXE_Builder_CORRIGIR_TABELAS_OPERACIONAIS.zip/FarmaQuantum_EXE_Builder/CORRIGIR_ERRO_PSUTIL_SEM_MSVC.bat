@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CORRIGIR ERRO PSUTIL - FARMA QUANTUM

echo ============================================================
echo   CORRIGIR ERRO PSUTIL / MICROSOFT VISUAL C++ 14
echo ============================================================
echo.
echo Este script corrige o problema:
echo "Microsoft Visual C++ 14.0 or greater is required"
echo.
echo Ele instala as dependencias principais sem obrigar compilar psutil.
echo.

python -m pip uninstall -y psutil
python -m pip install --upgrade pip setuptools wheel --prefer-binary
python -m pip install -r requirements.txt --prefer-binary --only-binary=:all:

echo.
echo Tentando psutil binario antigo/estavel...
python -m pip install "psutil==5.9.8" --only-binary=:all: --prefer-binary
if errorlevel 1 (
    echo.
    echo [AVISO] psutil nao foi instalado. Pode continuar.
    echo O sistema tem fallback e nao deve travar por ausencia de psutil.
) else (
    echo.
    echo [OK] psutil instalado.
)

echo.
pause
