@echo off
REM FARMA QUANTUM CHECK MYSQL CONNECTOR VERSION
python -c "import mysql.connector; print('[MYSQL CONNECTOR]', mysql.connector.__version__)"
REM FARMA QUANTUM FIX LOCK DEFINITIVO
if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
if exist C:\Quantum\.pdv_quantum_ultra.lock del /f /q C:\Quantum\.pdv_quantum_ultra.lock
chcp 65001 >nul
cd /d "%~dp0"
title COMPILAR EXE - FARMA QUANTUM - FIX MYSQL LOCALE ENG

echo ============================================================
echo   COMPILAR EXE FARMA QUANTUM - FIX MYSQL LOCALE ENG
echo ============================================================
echo.
echo Esta compilacao inclui explicitamente os arquivos internos do:
echo mysql.connector.locales.eng.client_error
echo.
echo Isso corrige o erro no EXE:
echo No localization support for language 'eng'
echo.

if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock

python -m PyInstaller ^
 --onefile ^
 --noconsole ^
 --clean ^
 --name FarmaQuantum ^
 --icon farmacia_moderno.ico ^
 --hidden-import=mysql.connector.locales.eng.client_error ^
 --hidden-import=mysql.connector.locales.client_error ^
 --hidden-import=mysql.connector.connection ^
 --hidden-import=mysql.connector.pooling ^
 --hidden-import=mysql.connector.errorcode ^
 --collect-submodules=mysql.connector ^
 --collect-submodules=mysql.connector.locales ^
 --collect-data=mysql.connector ^
 --copy-metadata=mysql-connector-python ^ ^
 --hidden-import=mysql.connector.plugins.mysql_native_password ^
 --hidden-import=mysql.connector.plugins.caching_sha2_password ^
 --hidden-import=mysql.connector.plugins.sha256_password ^
 --hidden-import=mysql.connector.plugins.mysql_clear_password ^
 --collect-submodules=mysql.connector.plugins ^
 --hidden-import=ttkbootstrap ^
 --hidden-import=ttkbootstrap.style ^
 --hidden-import=ttkbootstrap.widgets ^
 --hidden-import=ttkbootstrap.dialogs ^
 --hidden-import=ttkbootstrap.constants ^
 --hidden-import=ttkbootstrap.icons ^
 --collect-submodules=ttkbootstrap ^
 --collect-data=ttkbootstrap
 Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py

if errorlevel 1 (
    echo.
    echo [ERRO] Falha na compilacao.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo EXE gerado em: dist\FarmaQuantum.exe
echo ============================================================
echo.
pause
