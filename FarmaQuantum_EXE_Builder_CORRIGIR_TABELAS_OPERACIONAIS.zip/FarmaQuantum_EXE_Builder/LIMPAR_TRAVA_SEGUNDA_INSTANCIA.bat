@echo off
chcp 65001 >nul
cd /d "%~dp0"
title LIMPAR TRAVA DE INSTANCIA - FARMA QUANTUM

echo ============================================================
echo   LIMPAR TRAVA DE INSTANCIA - FARMA QUANTUM
echo ============================================================
echo.
echo Use este arquivo quando o sistema fechar imediatamente e o log mostrar:
echo "Tentativa de abrir segunda instancia bloqueada"
echo.

set "PASTA=%~dp0"
set "LOCK1=%PASTA%.pdv_quantum_ultra.lock"
set "LOCK2=%PASTA%dist\.pdv_quantum_ultra.lock"

if exist "%LOCK1%" (
    del /f /q "%LOCK1%"
    echo [OK] Removido: %LOCK1%
) else (
    echo [INFO] Nao existia: %LOCK1%
)

if exist "%LOCK2%" (
    del /f /q "%LOCK2%"
    echo [OK] Removido: %LOCK2%
) else (
    echo [INFO] Nao existia: %LOCK2%
)

echo.
echo Se houver FarmaQuantum.exe aberto no Gerenciador de Tarefas, finalize-o.
echo Depois abra o sistema novamente.
echo.
pause
