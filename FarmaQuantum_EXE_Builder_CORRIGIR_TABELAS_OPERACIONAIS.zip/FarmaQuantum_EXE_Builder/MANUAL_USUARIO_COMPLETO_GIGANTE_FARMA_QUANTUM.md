
# MANUAL COMPLETO DO USUÁRIO - FARMA QUANTUM

**Sistema:** Farma Quantum / PDV Quantum adaptado para Farmácia e Drogaria  
**Edição:** Manual operacional, administrativo, comercial e técnico  
**Data:** 05/06/2026  
**Objetivo:** ensinar, em linguagem simples e passo a passo, como usar o sistema em farmácias, drogarias, lojas de medicamentos, perfumaria, serviços farmacêuticos, ambulatório, controle de lote/validade, tratamentos contínuos, relatórios e permissões.

Este manual foi escrito para ser entendido por qualquer pessoa da farmácia: proprietário, gerente, farmacêutico, balconista, caixa, estoquista, atendente de convênio, responsável por compras, operador de delivery e administrador de sistema.

> Importante: este manual explica o uso do sistema. Para regras legais, fiscais, sanitárias, SNGPC, Farmácia Popular, PBM, LGPD e serviços clínicos, siga sempre a legislação vigente, as normas da Anvisa, CRF, Receita/SEFAZ e os procedimentos oficiais da sua empresa.


---

# SUMÁRIO

- [1. Visão geral do Farma Quantum](#1--visão-geral-do-farma-quantum)
- [2. Como abrir o sistema pela primeira vez](#2--como-abrir-o-sistema-pela-primeira-vez)
- [3. Compilar para EXE sem console](#3--compilar-para-exe-sem-console)
- [4. Configuração inicial do banco de dados MySQL](#4--configuração-inicial-do-banco-de-dados-mysql)
- [5. Estrutura automática do banco antes de iniciar](#5--estrutura-automática-do-banco-antes-de-iniciar)
- [6. Login e usuário administrador](#6--login-e-usuário-administrador)
- [7. Tela principal e menus](#7--tela-principal-e-menus)
- [8. Cadastro de produtos e medicamentos](#8--cadastro-de-produtos-e-medicamentos)
- [9. Cadastro de notas fiscais de entrada](#9--cadastro-de-notas-fiscais-de-entrada)
- [10. Controle de lote e validade](#10--controle-de-lote-e-validade)
- [11. Vendas no balcão](#11--vendas-no-balcão)
- [12. Descontos, acréscimos e formas de pagamento](#12--descontos--acréscimos-e-formas-de-pagamento)
- [13. Clientes e pacientes](#13--clientes-e-pacientes)
- [14. Fornecedores](#14--fornecedores)
- [15. Tratamento contínuo e lembrete de compra](#15--tratamento-contínuo-e-lembrete-de-compra)
- [16. Usando WhatsApp no tratamento contínuo](#16--usando-whatsapp-no-tratamento-contínuo)
- [17. Prontuário ambulatorial da farmácia](#17--prontuário-ambulatorial-da-farmácia)
- [18. Como registrar atendimento ambulatorial](#18--como-registrar-atendimento-ambulatorial)
- [19. Classificação de risco no ambulatório](#19--classificação-de-risco-no-ambulatório)
- [20. Farmácia Pro - recursos comerciais avançados](#20--farmácia-pro---recursos-comerciais-avançados)
- [21. Receituário, controlados e SNGPC](#21--receituário--controlados-e-sngpc)
- [22. PBM, convênios e Farmácia Popular](#22--pbm--convênios-e-farmácia-popular)
- [23. Campanhas, ofertas e encartes](#23--campanhas--ofertas-e-encartes)
- [24. Serviços farmacêuticos](#24--serviços-farmacêuticos)
- [25. Pós-venda e CRM](#25--pós-venda-e-crm)
- [26. Relatórios Farma](#26--relatórios-farma)
- [27. Impressão A4](#27--impressão-a4)
- [28. Impressão em bobina 80mm](#28--impressão-em-bobina-80mm)
- [29. Impressão em bobina 58mm](#29--impressão-em-bobina-58mm)
- [30. Gerenciamento de usuários e permissões granular](#30--gerenciamento-de-usuários-e-permissões-granular)
- [31. Permissões atômicas](#31--permissões-atômicas)
- [32. Perfis rápidos de permissão](#32--perfis-rápidos-de-permissão)
- [33. Administrador total e usuários blindados](#33--administrador-total-e-usuários-blindados)
- [34. Auditoria e rastreabilidade](#34--auditoria-e-rastreabilidade)
- [35. Backup e segurança de dados](#35--backup-e-segurança-de-dados)
- [36. Boas práticas de LGPD e privacidade](#36--boas-práticas-de-lgpd-e-privacidade)
- [37. Rotina diária recomendada](#37--rotina-diária-recomendada)
- [38. Solução de problemas comuns](#38--solução-de-problemas-comuns)
- [39. Dependências opcionais](#39--dependências-opcionais)
- [40. Glossário simples](#40--glossário-simples)
- [41. Roteiro detalhado: Produtos e medicamentos](#41--roteiro-detalhado--produtos-e-medicamentos)
- [42. Roteiro detalhado: Clientes e pacientes](#42--roteiro-detalhado--clientes-e-pacientes)
- [43. Roteiro detalhado: Fornecedores](#43--roteiro-detalhado--fornecedores)
- [44. Roteiro detalhado: Vendas e caixa](#44--roteiro-detalhado--vendas-e-caixa)
- [45. Roteiro detalhado: Notas fiscais de entrada](#45--roteiro-detalhado--notas-fiscais-de-entrada)
- [46. Roteiro detalhado: Lote e validade](#46--roteiro-detalhado--lote-e-validade)
- [47. Roteiro detalhado: Tratamento contínuo](#47--roteiro-detalhado--tratamento-contínuo)
- [48. Roteiro detalhado: Ambulatório](#48--roteiro-detalhado--ambulatório)
- [49. Roteiro detalhado: Receituário e controlados](#49--roteiro-detalhado--receituário-e-controlados)
- [50. Roteiro detalhado: PBM e convênios](#50--roteiro-detalhado--pbm-e-convênios)
- [51. Roteiro detalhado: Campanhas e ofertas](#51--roteiro-detalhado--campanhas-e-ofertas)
- [52. Roteiro detalhado: Serviços farmacêuticos](#52--roteiro-detalhado--serviços-farmacêuticos)
- [53. Roteiro detalhado: CRM e pós-venda](#53--roteiro-detalhado--crm-e-pós-venda)
- [54. Roteiro detalhado: Relatórios](#54--roteiro-detalhado--relatórios)
- [55. Roteiro detalhado: Impressões térmicas](#55--roteiro-detalhado--impressões-térmicas)
- [56. Roteiro detalhado: Configuração do banco](#56--roteiro-detalhado--configuração-do-banco)
- [57. Roteiro detalhado: Usuários e permissões](#57--roteiro-detalhado--usuários-e-permissões)
- [Permissões atômicas - grupo 01](#permissões-atômicas---grupo-01)
- [Permissões atômicas - grupo 02](#permissões-atômicas---grupo-02)
- [Permissões atômicas - grupo 03](#permissões-atômicas---grupo-03)
- [Permissões atômicas - grupo 04](#permissões-atômicas---grupo-04)
- [Permissões atômicas - grupo 05](#permissões-atômicas---grupo-05)
- [Permissões atômicas - grupo 06](#permissões-atômicas---grupo-06)
- [Permissões atômicas - grupo 07](#permissões-atômicas---grupo-07)
- [Permissões atômicas - grupo 08](#permissões-atômicas---grupo-08)
- [Permissões atômicas - grupo 09](#permissões-atômicas---grupo-09)
- [Permissões atômicas - grupo 10](#permissões-atômicas---grupo-10)
- [Permissões atômicas - grupo 11](#permissões-atômicas---grupo-11)
- [Permissões atômicas - grupo 12](#permissões-atômicas---grupo-12)
- [Permissões atômicas - grupo 13](#permissões-atômicas---grupo-13)
- [Permissões atômicas - grupo 14](#permissões-atômicas---grupo-14)
- [Permissões atômicas - grupo 15](#permissões-atômicas---grupo-15)
- [Permissões atômicas - grupo 16](#permissões-atômicas---grupo-16)
- [Permissões atômicas - grupo 17](#permissões-atômicas---grupo-17)
- [Permissões atômicas - grupo 18](#permissões-atômicas---grupo-18)
- [Permissões atômicas - grupo 19](#permissões-atômicas---grupo-19)
- [Permissões atômicas - grupo 20](#permissões-atômicas---grupo-20)
- [Permissões atômicas - grupo 21](#permissões-atômicas---grupo-21)
- [Permissões atômicas - grupo 22](#permissões-atômicas---grupo-22)
- [Permissões atômicas - grupo 23](#permissões-atômicas---grupo-23)
- [Permissões atômicas - grupo 24](#permissões-atômicas---grupo-24)
- [Permissões atômicas - grupo 25](#permissões-atômicas---grupo-25)
- [FAQ gigante - perguntas e respostas operacionais](#faq-gigante---perguntas-e-respostas-operacionais)
- [Checklists prontos para uso](#checklists-prontos-para-uso)
- [Encerramento e suporte interno](#encerramento-e-suporte-interno)

---


## 1. Visão geral do Farma Quantum

O Farma Quantum é um sistema comercial para farmácias e drogarias. Ele reúne venda, estoque, clientes, medicamentos, lote e validade, tratamentos contínuos, prontuário ambulatorial, relatórios, impressões, usuários e permissões em uma única aplicação.

A proposta do sistema é funcionar como uma central da farmácia. O operador consegue vender no balcão, localizar medicamentos, acompanhar validade, registrar tratamentos de uso contínuo, fazer lembrete de recompra, registrar atendimento farmacêutico, controlar permissões de funcionários e gerar relatórios em A4 ou bobina térmica.

O sistema possui visual adaptado para farmácia, cores mais clínicas e menus voltados a medicamentos, drogaria, serviços farmacêuticos e gestão comercial.

Use este manual como roteiro de implantação, treinamento e consulta diária.


## 2. Como abrir o sistema pela primeira vez

1. Extraia o arquivo ZIP em uma pasta simples, por exemplo `C:\Quantum` ou `C:\FarmaQuantum`.
2. Caso ainda não tenha compilado o EXE, execute primeiro `INSTALAR_DEPENDENCIAS.bat`.
3. Depois execute `COMPILAR_EXE_NOCONSOLE_ONEFILE.bat`.
4. O sistema irá gerar o executável dentro da pasta `dist`.
5. Abra o EXE gerado.
6. Na primeira execução, o sistema pode pedir configuração do banco MySQL.
7. Preencha host, porta, usuário, senha e banco.
8. Clique em testar conexão.
9. Se estiver correto, clique em salvar e iniciar.

A primeira abertura pode demorar um pouco mais porque o sistema prepara arquivos, configurações, auditoria, banco de dados, pastas e estruturas internas.


## 3. Compilar para EXE sem console

O pacote inclui um BAT pronto para gerar um executável único, sem janela preta de console e com ícone de farmácia.

Passo a passo:

1. Abra a pasta do pacote.
2. Clique duas vezes em `INSTALAR_DEPENDENCIAS.bat`.
3. Aguarde instalar PyInstaller, ttkbootstrap, mysql connector e demais bibliotecas.
4. Clique em `COMPILAR_EXE_NOCONSOLE_ONEFILE.bat`.
5. Aguarde a conclusão.
6. Ao terminar, entre na pasta `dist`.
7. O EXE estará lá.

Se der erro por biblioteca ausente, rode novamente o instalador de dependências. Se o antivírus demorar para liberar o EXE, aguarde ou coloque a pasta em exceção, desde que você confie no arquivo.


## 4. Configuração inicial do banco de dados MySQL

A tela de configuração do banco aparece quando o sistema não encontra `config.ini` ou quando a conexão falha.

Campos principais:

- Host: endereço do servidor MySQL. Em máquina local, use `127.0.0.1`.
- Porta: normalmente `3306`.
- Usuário: usuário do banco, por exemplo `usuario`.
- Senha: senha do usuário.
- Nome do Banco de Dados: nome do banco, por exemplo `farmacia`.

Botões importantes:

- Testar Conexão: verifica se os dados funcionam.
- Criar Banco/Usuário: tenta criar o banco e liberar usuário usando um administrador MySQL.
- Gerar SQL: cria um script para executar manualmente no MySQL Workbench.
- Usuário em Todos Bancos: libera o usuário escolhido para acessar qualquer banco.
- Banco p/ Todos: libera o banco escolhido para usuários existentes.
- bind 0.0.0.0: tenta configurar o MySQL para aceitar conexões externas.
- Salvar e Iniciar: grava a configuração e abre o sistema.

Se o MySQL negar acesso, o problema normalmente é usuário/senha incorreto ou falta de permissão. Nesse caso, use o botão Gerar SQL e execute o script no MySQL Workbench com usuário administrador.


## 5. Estrutura automática do banco antes de iniciar

O sistema possui pré-inicialização estrutural. Antes de iniciar processos principais, ele confere se o banco contém tabelas e colunas essenciais.

O que ele tenta preparar:

- tabelas de produtos;
- clientes;
- fornecedores;
- usuários;
- vendas;
- itens de venda;
- notas de entrada;
- empresa;
- categorias;
- configurações;
- lotes e validade;
- tratamentos contínuos;
- prontuário ambulatorial;
- receituário/controlados;
- PBM e convênios;
- campanhas;
- serviços farmacêuticos;
- CRM.

A migração é segura: a intenção é criar o que falta, sem apagar dados existentes. Mesmo assim, antes de usar em produção, faça backup do banco.


## 6. Login e usuário administrador

Ao abrir o sistema, informe usuário e senha.

Usuários administrativos blindados:

- `adm`
- `phda`

Esses usuários são considerados administradores totais. Eles devem manter acesso completo para evitar bloqueio acidental do sistema.

Boas práticas:

1. Crie um usuário para cada funcionário.
2. Não compartilhe a senha do administrador.
3. Use perfis de permissões por função.
4. Altere senhas periodicamente.
5. Revise usuários inativos.


## 7. Tela principal e menus

A tela principal é a central do sistema. Nela ficam os menus de operação diária.

Menus comuns:

- Vendas / PDV;
- Produtos / Medicamentos;
- Clientes;
- Fornecedores;
- Estoque;
- Notas fiscais de entrada;
- Tratamentos contínuos;
- Ambulatório / Prontuário;
- Farmácia Pro;
- Relatórios Farma;
- Usuários e permissões;
- Configurações.

Cada menu pode aparecer ou ficar oculto conforme as permissões do usuário logado.


## 8. Cadastro de produtos e medicamentos

Use o cadastro de produtos para registrar medicamentos, perfumaria, suplementos, correlatos, conveniência, produtos hospitalares e itens gerais da loja.

Campos típicos:

- Código;
- Descrição;
- Grupo/categoria;
- Unidade;
- Preço de compra;
- Preço de venda;
- Estoque;
- Código de barras;
- Ativo/inativo;
- Observação;
- Dados de lote e validade, quando ativados.

Passo a passo:

1. Abra Produtos/Medicamentos.
2. Clique em Novo.
3. Informe descrição clara do medicamento.
4. Informe código de barras, se tiver.
5. Informe grupo, preço e estoque.
6. Marque ativo.
7. Salve.

Dica: use nomes padronizados. Exemplo: `DIPIRONA 500MG 10 COMPRIMIDOS`.


## 9. Cadastro de notas fiscais de entrada

A entrada de nota fiscal serve para registrar chegada de produtos na farmácia.

Passo a passo:

1. Abra Cadastro/Entrada de Notas Fiscais.
2. Informe fornecedor e dados da nota.
3. Adicione os produtos recebidos.
4. Informe quantidade e valor.
5. Se o produto tiver controle de lote/validade, marque o checkbox de controle.
6. Informe lote e validade.
7. Salve a entrada.

A entrada pode atualizar estoque e alimentar alertas de vencimento.


## 10. Controle de lote e validade

O controle de lote e validade é essencial para farmácias.

Na entrada de nota existe o checkbox:

**Controlar lote e validade deste medicamento/produto**

Quando marcado, o sistema libera campos de lote e validade.

Quando não marcado, a função de alerta de validade não é usada para aquele produto.

Alertas:

- 15 dias antes: produto perto de vencer.
- No dia da validade: último dia de validade.
- Depois da data: produto vencido.

Rotina recomendada:

1. Conferir alertas toda manhã.
2. Separar produtos perto de vencer.
3. Bloquear venda de vencidos conforme procedimento da empresa.
4. Registrar retirada, devolução ou descarte quando aplicável.


## 11. Vendas no balcão

A tela de vendas é usada para atendimento normal no balcão.

Passo a passo básico:

1. Abra a tela de vendas.
2. Busque o medicamento pelo nome ou código de barras.
3. Adicione o item à venda.
4. Confira quantidade.
5. Aplique desconto, se permitido.
6. Escolha forma de pagamento.
7. Finalize.
8. Imprima cupom/recibo, se necessário.

Cuidados:

- confira sempre o produto antes de finalizar;
- verifique validade/lote quando necessário;
- para controlados, siga regras internas e legais;
- se houver erro, use cancelamento apenas com permissão.


## 12. Descontos, acréscimos e formas de pagamento

O sistema pode trabalhar com desconto, acréscimo, valor pago e troco.

Formas comuns:

- Dinheiro;
- PIX;
- Cartão débito;
- Cartão crédito;
- Convênio;
- PBM;
- Farmácia Popular;
- Outros.

Boas práticas:

1. Somente usuários autorizados devem conceder desconto.
2. Descontos altos devem exigir perfil de gerente.
3. Cancelamento e devolução devem exigir senha/permissão.
4. Sangria e suprimento devem ser registrados.


## 13. Clientes e pacientes

O cadastro de cliente/paciente ajuda em vendas, tratamentos contínuos, serviços farmacêuticos e pós-venda.

Campos importantes:

- Nome;
- Telefone;
- WhatsApp;
- CPF/documento;
- Endereço;
- Data de nascimento;
- Observações;
- Responsável, quando aplicável.

Use cadastro completo quando o cliente participar de tratamento contínuo, convênio, PBM, delivery, serviços farmacêuticos ou prontuário.


## 14. Fornecedores

O cadastro de fornecedores organiza compras e entradas de nota.

Registre:

- Razão social;
- Nome fantasia;
- CNPJ;
- Telefone;
- WhatsApp;
- E-mail;
- Endereço;
- Observações comerciais;
- Prazo médio de entrega.

Isso facilita controle de reposição, negociação e histórico.


## 15. Tratamento contínuo e lembrete de compra

Esse módulo ajuda a acompanhar clientes que compram medicamentos de uso contínuo.

Campos principais:

- Cliente/paciente;
- Telefone/WhatsApp;
- Medicamento/produto;
- Dose/posologia;
- Consumo por dia;
- Quantidade comprada;
- Intervalo manual em dias;
- Avisar quantos dias antes;
- Data da compra/início;
- Observação;
- Tratamento ativo;
- Tratamento contínuo.

Como cadastrar:

1. Abra Tratamento Contínuo.
2. Selecione o cliente.
3. Selecione o medicamento.
4. Informe consumo por dia.
5. Informe quantidade comprada.
6. O sistema calcula quando deve acabar.
7. Informe quantos dias antes deseja avisar.
8. Salve.

Quando chegar perto da data, o sistema informa que está na hora de lembrar o cliente da próxima compra.


## 16. Usando WhatsApp no tratamento contínuo

O botão WhatsApp cria uma mensagem pronta para o cliente.

Exemplo de uso:

1. Abra Tratamento Contínuo.
2. Selecione o cliente.
3. Clique no botão WhatsApp.
4. O navegador abre com mensagem pronta.
5. Revise a mensagem antes de enviar.

Nunca envie informação sensível sem autorização do cliente. Evite expor diagnóstico. Prefira mensagens simples: “Olá, passando para lembrar da sua recompra do medicamento de uso contínuo.”


## 17. Prontuário ambulatorial da farmácia

O prontuário ambulatorial registra atendimentos clínicos/farmacêuticos realizados na farmácia.

Pode incluir:

- identificação do paciente;
- responsável;
- profissional;
- registro/CRF;
- tipo de atendimento;
- classificação de risco;
- pressão arterial;
- frequência cardíaca;
- temperatura;
- saturação;
- glicemia;
- peso;
- altura;
- IMC;
- queixa principal;
- anamnese;
- alergias;
- doenças conhecidas;
- medicamentos em uso;
- interações;
- avaliação farmacêutica;
- conduta;
- orientações;
- encaminhamento;
- retorno;
- consentimento.

Use esse módulo com responsabilidade profissional. Ele não substitui atendimento médico quando houver sinais de gravidade.


## 18. Como registrar atendimento ambulatorial

Passo a passo:

1. Abra Ambulatório / Prontuário.
2. Clique em Novo.
3. Informe paciente e documento.
4. Informe data/hora.
5. Preencha sinais vitais.
6. Descreva queixa principal.
7. Registre anamnese e medicamentos em uso.
8. Informe alergias.
9. Registre avaliação farmacêutica.
10. Informe conduta e orientação.
11. Marque termo/consentimento, quando aplicável.
12. Salve.
13. Imprima ou envie orientação, se necessário.


## 19. Classificação de risco no ambulatório

A classificação de risco ajuda a orientar a prioridade.

Sugestão de interpretação operacional:

- Verde: situação simples, orientação comum.
- Amarelo: atenção, acompanhar e orientar retorno/serviço de saúde.
- Vermelho: emergência ou necessidade de encaminhamento imediato.

Se o sistema alertar risco vermelho, a equipe deve orientar encaminhamento urgente conforme protocolo da farmácia.


## 20. Farmácia Pro - recursos comerciais avançados

O módulo Farmácia Pro concentra recursos comerciais e operacionais modernos.

Áreas principais:

- Receituário e controlados;
- PBM, convênios e Farmácia Popular;
- Campanhas e ofertas;
- Serviços farmacêuticos;
- Pós-venda e CRM;
- Dashboard de alertas.

Use esse módulo para organizar atividades comerciais além da venda normal.


## 21. Receituário, controlados e SNGPC

Esse controle ajuda a registrar itens que dependem de receita, antibióticos, controlados ou psicotrópicos.

Campos comuns:

- Cliente/paciente;
- Medicamento;
- Tipo de controle;
- Prescritor;
- CRM;
- Data da receita;
- Validade da receita;
- Lote dispensado;
- Observação;
- Controle SNGPC.

Atenção: o sistema ajuda no registro, mas a responsabilidade legal de escrituração, guarda de documentos e cumprimento das normas é da farmácia.


## 22. PBM, convênios e Farmácia Popular

O módulo PBM/Convênios ajuda a controlar descontos e autorizações.

Pode registrar:

- nome do convênio;
- tipo de benefício;
- autorização;
- desconto;
- validade;
- cliente;
- medicamento;
- observação.

Antes de finalizar venda por convênio, confira autorização, documento, regras da operadora e comprovantes.


## 23. Campanhas, ofertas e encartes

Use campanhas para planejar promoções.

Tipos:

- oferta;
- combo;
- encarte;
- cashback;
- sazonal;
- balcão;
- delivery;
- WhatsApp;
- Instagram.

Passo a passo:

1. Abra Farmácia Pro.
2. Vá para Campanhas.
3. Cadastre título da campanha.
4. Informe data inicial e final.
5. Informe canal.
6. Registre produtos participantes.
7. Salve.
8. Use relatórios para acompanhar campanhas vencendo.


## 24. Serviços farmacêuticos

Serviços possíveis:

- aferição de pressão;
- glicemia capilar;
- teste rápido;
- vacinação;
- aplicação de injetável;
- consulta farmacêutica;
- acompanhamento.

Passo a passo:

1. Cadastre cliente/paciente.
2. Escolha o serviço.
3. Informe profissional responsável.
4. Marque data e hora.
5. Registre status.
6. Após atendimento, registre no prontuário.
7. Imprima comprovante, se necessário.


## 25. Pós-venda e CRM

O CRM ajuda a farmácia vender melhor sem perder organização.

Usos comuns:

- lembrar recompra;
- avisar campanha;
- verificar satisfação;
- chamar cliente inativo;
- organizar delivery;
- acompanhar retorno farmacêutico.

Boas práticas:

1. Tenha autorização do cliente para contato.
2. Evite mensagens excessivas.
3. Mantenha tom profissional e respeitoso.
4. Não exponha dados sensíveis.


## 26. Relatórios Farma

A central de relatórios permite gerar informações para gestão, operação e conferência.

Relatórios disponíveis:

- Produtos vencidos/vencendo por lote;
- Estoque baixo/reposição;
- Tratamentos contínuos e recompra;
- Prontuários ambulatoriais;
- Receituário/controlados/SNGPC;
- PBM/convênios/Farmácia Popular;
- Campanhas/ofertas;
- Serviços farmacêuticos;
- Pós-venda/CRM;
- Vendas recentes;
- Dashboard executivo.

Formatos:

- A4 em HTML;
- Bobina 80mm em TXT;
- Bobina 58mm em TXT.


## 27. Impressão A4

Use A4 para relatórios administrativos, conferências, arquivo interno e gestão.

Passo a passo:

1. Abra Relatórios Farma.
2. Escolha o tipo de relatório.
3. Escolha formato A4.
4. Clique em atualizar prévia.
5. Clique em gerar/imprimir.
6. O sistema cria arquivo HTML.
7. Use o navegador para imprimir em papel A4 ou salvar em PDF.

A4 é ideal para relatórios extensos, com cabeçalho e mais detalhes.


## 28. Impressão em bobina 80mm

Bobina 80mm é comum em impressoras térmicas de balcão.

Use para:

- comprovantes;
- resumo rápido;
- lista pequena de alerta;
- conferência de lote;
- lembrete de tratamento;
- serviço agendado.

Passo a passo:

1. Abra Relatórios Farma.
2. Escolha relatório.
3. Escolha Bobina 80mm.
4. Gere o relatório.
5. Se o Windows permitir, o sistema tenta imprimir diretamente.
6. Caso contrário, abra o TXT gerado e imprima manualmente.


## 29. Impressão em bobina 58mm

Bobina 58mm é mais estreita. O relatório precisa ser mais compacto.

Use para comprovantes simples e textos curtos.

Dicas:

- evite relatórios longos;
- prefira resumo;
- confira se a fonte está adequada;
- teste com a impressora instalada no Windows.


## 30. Gerenciamento de usuários e permissões granular

Essa tela controla quem pode acessar cada área do sistema.

Ela permite cadastrar usuário, senha, nível de acesso e permissões detalhadas.

A tela mostra:

- detalhes do usuário;
- lista de usuários cadastrados;
- grupos de permissões por módulo;
- seleção granular de ações;
- perfis rápidos;
- botões de auditoria e matriz.

Use essa tela com cuidado. Permissões mal configuradas podem liberar função demais ou bloquear função necessária.


## 31. Permissões atômicas

Permissões atômicas são permissões pequenas, específicas e detalhadas.

Em vez de liberar apenas “Produtos”, o administrador pode liberar ações como:

- abrir tela;
- cadastrar;
- editar;
- excluir;
- imprimir;
- exportar;
- alterar preço;
- alterar estoque;
- ver custo;
- aplicar desconto;
- cancelar venda;
- acessar configuração;
- editar campo específico.

Esse modelo reduz erro, melhora segurança e permite criar perfis fiéis à função real do funcionário.


## 32. Perfis rápidos de permissão

Perfis rápidos ajudam a aplicar conjuntos prontos.

Perfis disponíveis:

- Administrador Total;
- Gerente Farmacêutico;
- Farmacêutico Responsável;
- Balconista/Atendente;
- Caixa Restrito;
- Estoquista;
- Ambulatório;
- Somente Consulta.

Como usar:

1. Abra Gerenciamento de Usuários.
2. Selecione ou crie usuário.
3. Escolha um perfil rápido.
4. Clique em aplicar perfil.
5. Revise manualmente as permissões.
6. Salve.

Nunca aplique perfil sem revisar quando o funcionário tiver função especial.


## 33. Administrador total e usuários blindados

Usuários `adm` e `phda` são tratados como administradores totais.

Eles devem permanecer com acesso completo para manutenção, correção e recuperação.

Recomendação:

- use senha forte;
- não use no caixa comum;
- não compartilhe com balconistas;
- guarde em local seguro;
- crie usuários comuns para rotina diária.


## 34. Auditoria e rastreabilidade

O sistema possui auditoria global. Ela registra início, processos, erros, ações e eventos importantes.

Os arquivos de auditoria ficam em pasta própria.

Use auditoria para:

- verificar falhas;
- acompanhar login;
- entender erro de banco;
- rastrear operação crítica;
- analisar permissões negadas;
- suporte técnico.

Não apague auditorias recentes antes de investigar problemas.


## 35. Backup e segurança de dados

Toda farmácia deve ter rotina de backup.

Recomendação mínima:

- backup diário do banco;
- backup semanal fora do computador;
- backup antes de atualização;
- backup antes de mexer em permissões avançadas;
- backup antes de migração estrutural.

Armazene cópias em local seguro. Teste a restauração periodicamente.


## 36. Boas práticas de LGPD e privacidade

Farmácias lidam com dados sensíveis. Cuide da privacidade.

Boas práticas:

- cada funcionário com seu usuário;
- senha individual;
- acesso mínimo necessário;
- não compartilhar prontuário sem autorização;
- não expor doença ou medicamento em mensagens;
- cuidado com WhatsApp;
- manter computador bloqueado quando ausente;
- revisar permissões de usuários desligados.


## 37. Rotina diária recomendada

Ao abrir a farmácia:

1. Ligue computador e impressoras.
2. Abra o Farma Quantum.
3. Confira conexão com banco.
4. Verifique alertas de validade.
5. Verifique tratamentos/recompras do dia.
6. Verifique serviços agendados.
7. Abra caixa, se aplicável.
8. Faça vendas normalmente.

Durante o dia:

- registre entradas;
- mantenha estoque atualizado;
- registre atendimentos;
- confira descontos;
- imprima comprovantes.

Ao fechar:

- confira caixa;
- gere relatório do dia;
- faça backup;
- feche o sistema corretamente.


## 38. Solução de problemas comuns

Erro de MySQL “Access denied”:

- usuário ou senha incorretos;
- usuário sem permissão;
- banco inexistente;
- host errado;
- MySQL parado.

Erro de `ttkbootstrap`:

- dependência ausente ou versão incompatível;
- rode instalador de dependências.

Erro de impressão:

- impressora não instalada;
- nome da impressora diferente;
- driver térmico ausente;
- tente abrir o arquivo gerado e imprimir manualmente.

Sistema abre mas menu não funciona:

- verifique permissões do usuário;
- teste como administrador;
- veja auditoria.

EXE não abre:

- compile novamente;
- rode como administrador;
- verifique antivírus;
- teste o `.py` direto no Python para ver mensagem.


## 39. Dependências opcionais

Alguns avisos no console não impedem o sistema de funcionar.

Exemplos:

- PySerial: usado para balança serial.
- PyBluez/Bleak: usado para Bluetooth.
- Flask: usado para servidor web interno.
- ReportLab: usado para PDF em algumas rotinas.

Se a farmácia não usa essas funções, os avisos podem ser ignorados. Se quiser ativar, instale as dependências opcionais.


## 40. Glossário simples

- PDV: ponto de venda, tela usada para vender.
- Lote: identificação do lote de fabricação do produto.
- Validade: data máxima de uso/venda conforme embalagem e legislação.
- PBM: programa de benefício em medicamentos.
- CRM: relacionamento com cliente; também pode significar registro médico, dependendo do contexto. No sistema, CRM comercial é pós-venda; CRM do prescritor é registro profissional.
- SNGPC: sistema relacionado a controle de medicamentos sujeitos a controle especial.
- Prontuário: registro de atendimento ao paciente.
- Permissão atômica: autorização pequena e específica para uma ação ou componente.


## 41. Roteiro detalhado: Produtos e medicamentos

Este capítulo mostra uma rotina prática para trabalhar com **Produtos e medicamentos**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Produtos e medicamentos**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 42. Roteiro detalhado: Clientes e pacientes

Este capítulo mostra uma rotina prática para trabalhar com **Clientes e pacientes**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Clientes e pacientes**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 43. Roteiro detalhado: Fornecedores

Este capítulo mostra uma rotina prática para trabalhar com **Fornecedores**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Fornecedores**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 44. Roteiro detalhado: Vendas e caixa

Este capítulo mostra uma rotina prática para trabalhar com **Vendas e caixa**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Vendas e caixa**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 45. Roteiro detalhado: Notas fiscais de entrada

Este capítulo mostra uma rotina prática para trabalhar com **Notas fiscais de entrada**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Notas fiscais de entrada**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 46. Roteiro detalhado: Lote e validade

Este capítulo mostra uma rotina prática para trabalhar com **Lote e validade**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Lote e validade**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 47. Roteiro detalhado: Tratamento contínuo

Este capítulo mostra uma rotina prática para trabalhar com **Tratamento contínuo**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Tratamento contínuo**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 48. Roteiro detalhado: Ambulatório

Este capítulo mostra uma rotina prática para trabalhar com **Ambulatório**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Ambulatório**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 49. Roteiro detalhado: Receituário e controlados

Este capítulo mostra uma rotina prática para trabalhar com **Receituário e controlados**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Receituário e controlados**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 50. Roteiro detalhado: PBM e convênios

Este capítulo mostra uma rotina prática para trabalhar com **PBM e convênios**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **PBM e convênios**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 51. Roteiro detalhado: Campanhas e ofertas

Este capítulo mostra uma rotina prática para trabalhar com **Campanhas e ofertas**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Campanhas e ofertas**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 52. Roteiro detalhado: Serviços farmacêuticos

Este capítulo mostra uma rotina prática para trabalhar com **Serviços farmacêuticos**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Serviços farmacêuticos**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 53. Roteiro detalhado: CRM e pós-venda

Este capítulo mostra uma rotina prática para trabalhar com **CRM e pós-venda**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **CRM e pós-venda**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 54. Roteiro detalhado: Relatórios

Este capítulo mostra uma rotina prática para trabalhar com **Relatórios**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Relatórios**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 55. Roteiro detalhado: Impressões térmicas

Este capítulo mostra uma rotina prática para trabalhar com **Impressões térmicas**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Impressões térmicas**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 56. Roteiro detalhado: Configuração do banco

Este capítulo mostra uma rotina prática para trabalhar com **Configuração do banco**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Configuração do banco**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## 57. Roteiro detalhado: Usuários e permissões

Este capítulo mostra uma rotina prática para trabalhar com **Usuários e permissões**.

Antes de começar:

1. Entre com usuário autorizado.
2. Confirme se o menu correspondente aparece.
3. Se não aparecer, peça ao administrador para revisar permissões.
4. Evite usar usuário administrador para rotina comum.

Como incluir um registro:

1. Abra o módulo **Usuários e permissões**.
2. Clique em **Novo** ou no botão equivalente.
3. Preencha os campos obrigatórios primeiro.
4. Preencha os campos complementares.
5. Revise os dados digitados.
6. Clique em **Salvar**.
7. Confira se o registro apareceu na lista.

Como editar:

1. Pesquise o registro.
2. Selecione na lista.
3. Altere somente o necessário.
4. Clique em salvar/atualizar.
5. Verifique se a alteração ficou correta.

Como evitar erro:

- não deixe campos importantes em branco;
- revise datas;
- use valores numéricos com cuidado;
- não cadastre duplicado sem necessidade;
- em caso de dúvida, cancele e chame o responsável.

Permissões recomendadas:

- Administrador: acesso total.
- Gerente: cadastrar, editar, consultar, imprimir e auditar.
- Operador comum: consultar e executar rotina diária.
- Usuário restrito: somente consultar, quando necessário.


## Permissões atômicas - grupo 01

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 02

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 03

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 04

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 05

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 06

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 07

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 08

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 09

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 10

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 11

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 12

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 13

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 14

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 15

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 16

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 17

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 18

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 19

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 20

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 21

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 22

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 23

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 24

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## Permissões atômicas - grupo 25

Este grupo representa um conjunto de permissões que podem ser marcadas separadamente para controlar o sistema com precisão.

Exemplos de ações que devem ser avaliadas pelo administrador:

1. Abrir a tela.
2. Visualizar registros.
3. Criar novo registro.
4. Editar registro existente.
5. Excluir registro.
6. Cancelar operação.
7. Imprimir.
8. Exportar.
9. Ver valores de custo.
10. Alterar preço de venda.
11. Alterar estoque.
12. Aplicar desconto.
13. Autorizar operação crítica.
14. Acessar configurações.
15. Alterar campos sensíveis.

Como decidir:

- Marque apenas o que o funcionário realmente precisa.
- Não dê permissão de exclusão para todos.
- Não libere configuração de banco para usuário comum.
- Não libere alteração de preço para caixa restrito.
- Revise permissões quando o funcionário mudar de função.

Teste sempre após salvar:

1. Entre com o usuário configurado.
2. Tente abrir o módulo.
3. Tente executar a ação permitida.
4. Tente executar uma ação não permitida.
5. Confirme se o sistema bloqueia corretamente.


## FAQ gigante - perguntas e respostas operacionais

### Pergunta 1: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 1: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 2: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 2: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 3: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 3: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 4: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 4: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 5: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 5: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 6: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 6: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 7: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 7: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 8: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 8: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 9: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 9: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 10: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 10: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 11: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 11: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 12: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 12: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 13: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 13: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 14: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 14: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 15: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 15: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 16: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 16: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 17: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 17: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 18: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 18: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 19: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 19: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 20: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 20: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 21: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 21: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 22: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 22: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 23: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 23: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 24: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 24: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 25: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 25: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 26: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 26: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 27: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 27: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 28: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 28: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 29: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 29: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 30: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 30: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 31: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 31: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 32: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 32: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 33: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 33: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 34: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 34: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 35: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 35: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 36: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 36: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 37: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 37: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 38: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 38: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 39: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 39: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 40: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 40: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 41: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 41: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 42: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 42: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 43: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 43: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 44: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 44: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 45: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 45: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 46: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 46: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 47: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 47: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 48: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 48: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 49: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 49: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 50: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 50: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 51: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 51: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 52: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 52: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 53: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 53: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 54: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 54: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 55: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 55: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 56: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 56: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 57: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 57: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 58: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 58: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 59: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 59: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


### Pergunta 60: O que fazer quando uma função não aparece?

Verifique se o usuário tem permissão para abrir o módulo. Entre como administrador, abra Gerenciamento de Usuários e Permissões Granular, selecione o usuário, expanda o grupo correspondente, marque a permissão de abrir/visualizar e salve. Depois feche e abra novamente o sistema com o usuário testado.

### Pergunta 60: Como conferir se um erro é de permissão ou de sistema?

Teste a mesma ação com o usuário administrador. Se funcionar com administrador e não funcionar com usuário comum, provavelmente é permissão. Se não funcionar nem com administrador, veja auditoria, console, banco de dados ou dependência ausente.


## Checklists prontos para uso

## Checklist: Implantação inicial

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Treinamento de operador

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Treinamento de gerente

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Treinamento de farmacêutico

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Fechamento diário

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Conferência de estoque

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Controle de validade

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Permissões mensais

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Backup semanal

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Checklist: Auditoria de erros

- [ ] Conferir usuário responsável.
- [ ] Conferir acesso ao módulo necessário.
- [ ] Conferir se banco está conectado.
- [ ] Conferir se impressora está disponível, quando aplicável.
- [ ] Conferir se os dados foram salvos.
- [ ] Conferir se relatório foi gerado.
- [ ] Conferir se não há alerta pendente.
- [ ] Registrar observação, se necessário.
- [ ] Fazer backup quando a atividade alterar dados importantes.


## Encerramento e suporte interno

Este manual deve ficar junto ao sistema para treinamento dos funcionários. Sempre que uma nova função for adicionada, atualize o manual ou registre uma observação interna.

Para suporte, anote:

- data e hora do erro;
- usuário logado;
- tela usada;
- ação executada;
- mensagem exibida;
- print da tela;
- arquivo de auditoria mais recente.

Com essas informações, a correção fica muito mais rápida.
