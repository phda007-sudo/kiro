-- CORRIGIR TABELA USUARIOS - FARMA QUANTUM
-- Corrige: Unknown column 'password_hash' in 'field list'

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(120) UNIQUE,
    usuario VARCHAR(120),
    nome VARCHAR(255),
    password VARCHAR(255),
    password_hash VARCHAR(255),
    senha VARCHAR(255),
    nivel VARCHAR(80),
    nivel_acesso VARCHAR(80),
    permissoes LONGTEXT,
    vinculos LONGTEXT,
    ativo TINYINT DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @db := DATABASE();

SET @sql := IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='usuarios' AND COLUMN_NAME='password_hash') = 0,
  'ALTER TABLE usuarios ADD COLUMN password_hash VARCHAR(255)',
  'SELECT ''password_hash já existe'' AS info'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='usuarios' AND COLUMN_NAME='password') = 0,
  'ALTER TABLE usuarios ADD COLUMN password VARCHAR(255)',
  'SELECT ''password já existe'' AS info'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='usuarios' AND COLUMN_NAME='senha') = 0,
  'ALTER TABLE usuarios ADD COLUMN senha VARCHAR(255)',
  'SELECT ''senha já existe'' AS info'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='usuarios' AND COLUMN_NAME='nivel_acesso') = 0,
  'ALTER TABLE usuarios ADD COLUMN nivel_acesso VARCHAR(80)',
  'SELECT ''nivel_acesso já existe'' AS info'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='usuarios' AND COLUMN_NAME='permissoes') = 0,
  'ALTER TABLE usuarios ADD COLUMN permissoes LONGTEXT',
  'SELECT ''permissoes já existe'' AS info'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
