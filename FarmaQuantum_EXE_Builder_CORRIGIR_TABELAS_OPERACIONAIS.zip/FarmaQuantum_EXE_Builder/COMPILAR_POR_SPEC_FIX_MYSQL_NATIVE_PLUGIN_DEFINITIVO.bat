@echo off
chcp 65001 >nul
cd /d "%~dp0"
title COMPILAR POR SPEC - FIX MYSQL NATIVE PLUGIN

echo ============================================================
echo   COMPILAR POR SPEC - FIX MYSQL NATIVE PLUGIN
echo ============================================================
echo.

if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
if exist C:\Quantum\.pdv_quantum_ultra.lock del /f /q C:\Quantum\.pdv_quantum_ultra.lock

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

python -m PyInstaller --clean --noconfirm FarmaQuantum_FIX_MYSQL_NATIVE_PLUGIN_DEFINITIVO.spec

echo.
echo Se tudo deu certo:
echo dist\FarmaQuantum.exe
echo.
pause


REM FIX TTKBOOTSTRAP
python -m PyInstaller ^
 --onefile ^
 --noconsole ^
 --clean ^
 --name FarmaQuantum ^
 --icon farmacia_moderno.ico ^
 --hidden-import=ttkbootstrap ^
 --collect-submodules=ttkbootstrap ^
 --collect-data=ttkbootstrap ^
 Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
