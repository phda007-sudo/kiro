@echo off
chcp 65001 >nul
cd /d "%~dp0"
title DIAGNOSTICO TTKBOOTSTRAP E MYSQL - FARMA QUANTUM

echo ============================================================
echo   DIAGNOSTICO TTKBOOTSTRAP E MYSQL
echo ============================================================
echo.

python -c "import ttkbootstrap; print('ttkbootstrap: OK')" >nul 2>&1
if errorlevel 1 (
    echo [AVISO] ttkbootstrap nao encontrado. Instalando agora...
    python -m pip install --no-cache-dir "ttkbootstrap==1.20.3" --prefer-binary
)

python -c "import ttkbootstrap; print('ttkbootstrap: OK')"
python -c "import mysql.connector; print('mysql.connector:', mysql.connector.__version__)"
python -c "import mysql.connector.plugins.mysql_native_password; print('mysql_native_password: OK')"
python -c "import mysql.connector.locales.eng.client_error; print('locale eng: OK')"

echo.
pause
