# ROTEIRO COMERCIAL DE DEMONSTRAÇÃO – FARMA QUANTUM

## Objetivo
Ajudar o vendedor a conduzir uma conversa comercial consultiva, segura e encantadora, mostrando o que mais importa para uma farmácia.

## Estrutura sugerida da reunião
1. Quebra-gelo e diagnóstico
2. Levantamento de dores
3. Apresentação do sistema
4. Demonstração prática
5. Benefícios percebidos
6. Fechamento

## Perguntas de diagnóstico
- Como vocês controlam estoque hoje?
- Existe controle de lote e validade?
- Vocês trabalham com pacientes de uso contínuo?
- Há atendimento farmacêutico ou ambulatório?
- Como controlam o que cada funcionário pode fazer?
- Como acompanham campanhas, recompras e pós-venda?
- Como emitem relatórios?

## Demonstração sugerida
### 1. Tela principal
Mostrar que o sistema foi preparado para farmácia.

### 2. Cadastro de produto/medicamento
Mostrar informações organizadas, facilidade e profissionalismo.

### 3. Lote e validade
Demonstrar segurança e redução de perdas.

### 4. Tratamento contínuo
Demonstrar fidelização e inteligência de recompra.

### 5. Prontuário ambulatorial
Demonstrar atendimento diferenciado e posicionamento profissional.

### 6. Relatórios
Demonstrar visão de gestão.

### 7. Permissões atômicas
Demonstrar maturidade e segurança.

## Frases úteis
- “Aqui o senhor não compra apenas um sistema de venda, mas uma estrutura completa para a farmácia.”
- “Essa parte ajuda a evitar perdas e melhora o controle.”
- “Essa outra ajuda a fazer o cliente voltar no momento certo.”
- “Aqui está um diferencial importante para farmácias que querem atendimento profissional.”
- “E aqui está a camada de segurança para o gestor controlar a equipe.”

## Fechamento sugerido
“Vendo tudo isso na prática, faz sentido para o senhor trabalhar com um sistema que una controle, vendas, atendimento e fidelização dentro da farmácia?”
