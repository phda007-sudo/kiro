@echo off
chcp 65001 >nul
cd /d "%~dp0"
title COMPILAR EXE DEFINITIVO - FARMA QUANTUM

echo ============================================================
echo   COMPILAR EXE DEFINITIVO - FARMA QUANTUM
echo   ONEFILE + NOCONSOLE + ICON + TTKBOOTSTRAP + MYSQL FIX
echo ============================================================
echo.

echo [1/6] Instalando/corrigindo dependencias essenciais...
python -m pip install --upgrade pip setuptools wheel --prefer-binary
python -m pip uninstall -y ttkbootstrap
python -m pip install --no-cache-dir "ttkbootstrap==1.20.3" --prefer-binary
python -m pip install --no-cache-dir "mysql-connector-python==8.4.0" --prefer-binary
python -m pip install -r requirements.txt --prefer-binary
echo.

echo [2/6] Testando imports essenciais...
python -c "import ttkbootstrap; print('ttkbootstrap OK')"
if errorlevel 1 (
    echo [ERRO] ttkbootstrap nao esta instalado no Python atual.
    pause
    exit /b 1
)
python -c "import mysql.connector; print('mysql.connector', mysql.connector.__version__)"
python -c "import mysql.connector.plugins.mysql_native_password; print('mysql_native_password OK')"
python -c "import mysql.connector.locales.eng.client_error; print('mysql locale eng OK')"
if errorlevel 1 (
    echo [ERRO] mysql connector/locales/plugins incompletos.
    pause
    exit /b 1
)

echo.
echo [3/6] Limpando trava e builds antigos...
if exist .pdv_quantum_ultra.lock del /f /q .pdv_quantum_ultra.lock
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
if exist C:\Quantum\.pdv_quantum_ultra.lock del /f /q C:\Quantum\.pdv_quantum_ultra.lock
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist FarmaQuantum.spec del /f /q FarmaQuantum.spec

echo.
echo [4/6] Compilando EXE...
python -m PyInstaller ^
 --onefile ^
 --noconsole ^
 --clean ^
 --name FarmaQuantum ^
 --icon farmacia_moderno.ico ^
 --hidden-import=ttkbootstrap ^
 --hidden-import=ttkbootstrap.style ^
 --hidden-import=ttkbootstrap.widgets ^
 --hidden-import=ttkbootstrap.dialogs ^
 --hidden-import=ttkbootstrap.constants ^
 --hidden-import=ttkbootstrap.icons ^
 --collect-submodules=ttkbootstrap ^
 --collect-data=ttkbootstrap ^
 --hidden-import=mysql.connector.locales.eng.client_error ^
 --hidden-import=mysql.connector.locales.client_error ^
 --hidden-import=mysql.connector.plugins.mysql_native_password ^
 --hidden-import=mysql.connector.plugins.caching_sha2_password ^
 --hidden-import=mysql.connector.plugins.sha256_password ^
 --hidden-import=mysql.connector.plugins.mysql_clear_password ^
 --hidden-import=mysql.connector.connection ^
 --hidden-import=mysql.connector.pooling ^
 --hidden-import=mysql.connector.errorcode ^
 --collect-submodules=mysql.connector ^
 --collect-submodules=mysql.connector.locales ^
 --collect-submodules=mysql.connector.plugins ^
 --collect-data=mysql.connector ^
 --copy-metadata=mysql-connector-python ^
 Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py

if errorlevel 1 (
    echo.
    echo [ERRO] Falha na compilacao.
    pause
    exit /b 1
)

echo.
echo [5/6] Limpando locks finais...
if exist dist\.pdv_quantum_ultra.lock del /f /q dist\.pdv_quantum_ultra.lock
if exist C:\Quantum\.pdv_quantum_ultra.lock del /f /q C:\Quantum\.pdv_quantum_ultra.lock

echo.
echo [6/6] Concluido.
echo ============================================================
echo EXE gerado em:
echo dist\FarmaQuantum.exe
echo ============================================================
echo.
pause
