# CORREÇÃO DO ERRO MYSQL: No localization support for language 'eng'

## O que significa

A mensagem:

```text
No localization support for language 'eng'
```

não é erro de senha, não é erro do layout e não é erro do Farma Quantum.

Ela normalmente acontece quando a instalação do MySQL está com configuração antiga ou inválida de idioma, geralmente dentro do `my.ini` ou `my.cnf`:

```ini
language=eng
```

Essa configuração pode fazer o MySQL recusar a conexão antes mesmo de autenticar corretamente.

## Correção recomendada

Troque:

```ini
language=eng
```

por:

```ini
lc-messages=en_US
```

Depois reinicie o serviço do MySQL.

## Arquivos comuns

Procure o arquivo de configuração em locais como:

```text
C:\ProgramData\MySQL\MySQL Server 8.0\my.ini
C:\ProgramData\MySQL\MySQL Server 5.7\my.ini
C:\xampp\mysql\bin\my.ini
C:\laragon\bin\mysql\...\my.ini
```

## Correção automática

Execute como administrador:

```bat
CORRIGIR_MYSQL_LANGUAGE_ENG.bat
```

O script tenta:

1. localizar o `my.ini`;
2. criar backup;
3. substituir `language=eng` por `lc-messages=en_US`;
4. reiniciar o serviço do MySQL.

## Depois da correção

Abra novamente o Farma Quantum e teste:

```text
Host: 127.0.0.1
Porta: 3306
Usuário: usuario
Senha: sua senha
Banco: farmacia
```

Se o erro mudar para `Access denied`, aí o problema passa a ser usuário/senha/permissão do MySQL. Se conectar, está resolvido.
