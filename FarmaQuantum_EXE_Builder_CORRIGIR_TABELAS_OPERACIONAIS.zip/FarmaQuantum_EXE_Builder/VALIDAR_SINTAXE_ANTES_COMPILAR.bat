@echo off
chcp 65001 >nul
cd /d "%~dp0"
title VALIDAR SINTAXE - FARMA QUANTUM

echo ============================================================
echo   VALIDAR SINTAXE PYTHON - FARMA QUANTUM
echo ============================================================
echo.

python -m py_compile Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
if errorlevel 1 (
    echo.
    echo [ERRO] Existe erro de sintaxe/indentacao.
    pause
    exit /b 1
)

echo.
echo [OK] Sintaxe validada. Pode compilar.
echo.
pause
