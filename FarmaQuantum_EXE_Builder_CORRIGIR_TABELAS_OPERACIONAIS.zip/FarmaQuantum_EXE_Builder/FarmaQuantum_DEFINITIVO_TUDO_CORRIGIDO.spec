# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules, collect_data_files, copy_metadata

hiddenimports = []
hiddenimports += collect_submodules('ttkbootstrap')
hiddenimports += collect_submodules('mysql.connector')
hiddenimports += collect_submodules('mysql.connector.locales')
hiddenimports += collect_submodules('mysql.connector.plugins')
hiddenimports += [
    'ttkbootstrap',
    'ttkbootstrap.style',
    'ttkbootstrap.widgets',
    'ttkbootstrap.dialogs',
    'ttkbootstrap.constants',
    'ttkbootstrap.icons',
    'mysql.connector.locales.eng.client_error',
    'mysql.connector.locales.client_error',
    'mysql.connector.plugins.mysql_native_password',
    'mysql.connector.plugins.caching_sha2_password',
    'mysql.connector.plugins.sha256_password',
    'mysql.connector.plugins.mysql_clear_password',
    'mysql.connector.connection',
    'mysql.connector.pooling',
    'mysql.connector.errorcode',
]

datas = []
datas += collect_data_files('ttkbootstrap')
datas += collect_data_files('mysql.connector')
try:
    datas += copy_metadata('mysql-connector-python')
except Exception:
    pass

a = Analysis(
    ['Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py'],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='FarmaQuantum',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    icon='farmacia_moderno.ico',
)
