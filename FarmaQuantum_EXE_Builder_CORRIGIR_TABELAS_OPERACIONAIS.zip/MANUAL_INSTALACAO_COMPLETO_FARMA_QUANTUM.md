# MANUAL DE INSTALAÇÃO COMPLETO — FARMA QUANTUM

**Sistema:** Farma Quantum / PDV Quantum adaptado para farmácias e drogarias  
**Objetivo deste manual:** permitir que qualquer pessoa consiga instalar, configurar, testar, compilar e colocar o sistema em uso, mesmo sem experiência avançada em tecnologia.

---

## 1. Visão geral da instalação

A instalação do Farma Quantum pode ser feita de duas maneiras:

1. **Rodando direto pelo Python**, recomendado para testes, manutenção e desenvolvimento.
2. **Gerando um arquivo `.exe`**, recomendado para uso comercial no balcão, caixa, estoque e computadores da farmácia.

O pacote já acompanha arquivos `.bat` para facilitar:

- `INSTALAR_DEPENDENCIAS.bat`: instala bibliotecas necessárias.
- `COMPILAR_EXE_NOCONSOLE_ONEFILE.bat`: gera o executável em um único arquivo, sem console.
- `LIMPAR_BUILD.bat`: limpa arquivos temporários da compilação.

---

## 2. Requisitos mínimos do computador

### 2.1. Requisitos mínimos para uso simples

- Sistema operacional: Windows 10 ou Windows 11.
- Processador: Intel Core i3 ou equivalente.
- Memória RAM: 4 GB.
- Disco livre: 2 GB.
- Tela: 1366x768 ou superior.
- Impressora térmica ou comum opcional.
- MySQL instalado localmente ou em servidor de rede.

### 2.2. Requisitos recomendados para uso comercial

- Sistema operacional: Windows 10 Pro ou Windows 11 Pro.
- Processador: Intel Core i5 ou superior.
- Memória RAM: 8 GB ou mais.
- SSD com pelo menos 10 GB livres.
- Rede cabeada para caixa/servidor.
- Nobreak no computador principal e no roteador.
- Impressora térmica 80mm para cupom.
- Impressora A4 para relatórios e documentos.
- Leitor de código de barras USB.
- Backup externo ou em nuvem.

### 2.3. Requisitos para servidor local

- Windows 10/11, Windows Server ou Linux.
- MySQL 5.7, MySQL 8.0 ou MariaDB compatível.
- Porta 3306 liberada na rede local.
- IP fixo ou reserva DHCP no roteador.
- Firewall configurado para permitir conexões do sistema.

---

## 3. Requisitos de software

### 3.1. Python

Recomendado:

- Python 3.11.x.
- Pode ser 32-bit ou 64-bit, mas recomenda-se manter o mesmo padrão usado na máquina.

Durante a instalação do Python, marque:

- **Add Python to PATH**.
- **Install launcher for all users**, se disponível.

Teste no Prompt de Comando:

```bat
python --version
pip --version
```

Se aparecer a versão, está instalado corretamente.

### 3.2. MySQL

Instale MySQL Community Server ou MariaDB. Durante a instalação:

1. Defina uma senha para o usuário `root`.
2. Anote essa senha em local seguro.
3. Mantenha a porta padrão `3306`, salvo se já houver outro serviço usando.
4. Instale também o MySQL Workbench, se possível, para manutenção visual.

### 3.3. Bibliotecas Python principais

O pacote usa um arquivo `requirements.txt`. As principais bibliotecas esperadas são:

- `ttkbootstrap` para interface moderna.
- `mysql-connector-python` para conexão MySQL.
- `pillow` para imagens e ícones.
- `pyinstaller` para gerar `.exe`.
- `reportlab` para geração de relatórios PDF quando disponível.
- `psutil` para monitoramento do sistema quando disponível.
- `requests` para integrações HTTP quando disponível.

### 3.4. Bibliotecas opcionais para equipamentos e integrações

- `pyserial`: balanças e dispositivos seriais.
- `pybluez` ou `bleak`: Bluetooth.
- `flask`: servidor web local, comandas, painel ou recursos web.
- `python-escpos`: impressão ESC/POS avançada.
- `pywin32`: recursos específicos do Windows, impressão e automação.

---

## 4. Como instalar dependências

Entre na pasta extraída do sistema e execute:

```bat
INSTALAR_DEPENDENCIAS.bat
```

Ou manualmente:

```bat
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Para dependências opcionais:

```bat
pip install -r requirements_opcionais.txt
```

Se alguma dependência opcional falhar, o sistema ainda pode abrir, mas o recurso ligado a ela pode ficar indisponível.

---

## 5. Preparação das pastas

Recomendado criar a estrutura:

```text
C:\Quantum\
C:\Quantum\pdv_data\
C:\Quantum\auditoria\
C:\Quantum\relatorios_farmacia\
C:\Quantum\backup\
```

Coloque o sistema principal em:

```text
C:\Quantum\Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
```

---

## 6. Configuração inicial do banco MySQL

Ao abrir o sistema pela primeira vez, ele pode exibir a tela:

**Configuração do Banco de Dados MySQL - Farmácia**

Preencha:

```ini
Host: 127.0.0.1
Porta: 3306
Usuário: usuario
Senha: sua_senha
Banco: farmacia
```

Se o MySQL estiver em outro computador, use o IP do servidor, por exemplo:

```ini
Host: 192.168.0.100
Porta: 3306
Usuário: usuario
Senha: sua_senha
Banco: farmacia
```

---

## 7. Criar banco e liberar usuário pelo sistema

Na tela de configuração, use:

- **Criar Banco/Usuário**: cria banco e usuário usando credenciais administrativas.
- **Gerar SQL**: gera script para executar no MySQL Workbench.
- **Usuário em Todos Bancos**: libera o usuário para todos os bancos, quando necessário.
- **Banco p/ Todos**: libera o banco atual para usuários existentes.
- **bind 0.0.0.0**: tenta configurar o MySQL para aceitar conexões de rede.

Atenção: recursos administrativos precisam de usuário root ou outro usuário com permissão equivalente.

---

## 8. SQL manual para criação inicial

Quando preferir fazer manualmente no MySQL Workbench:

```sql
CREATE DATABASE IF NOT EXISTS farmacia
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'usuario'@'localhost' IDENTIFIED BY 'sua_senha';
CREATE USER IF NOT EXISTS 'usuario'@'%' IDENTIFIED BY 'sua_senha';

GRANT ALL PRIVILEGES ON farmacia.* TO 'usuario'@'localhost';
GRANT ALL PRIVILEGES ON farmacia.* TO 'usuario'@'%';

FLUSH PRIVILEGES;
```

Para rede local, confirme o `bind-address` do MySQL.

---

## 9. Configurar bind-address para rede

O arquivo geralmente fica em um destes locais:

```text
C:\ProgramData\MySQL\MySQL Server 8.0\my.ini
C:\Program Files\MySQL\MySQL Server 8.0\my.ini
/etc/mysql/mysql.conf.d/mysqld.cnf
```

Procure:

```ini
bind-address = 127.0.0.1
```

Troque para:

```ini
bind-address = 0.0.0.0
```

Depois reinicie o serviço MySQL.

No Windows:

```bat
services.msc
```

Procure MySQL e clique em reiniciar.

---

## 10. Firewall do Windows

Para permitir acesso de outros computadores:

1. Abra Firewall do Windows.
2. Regras de Entrada.
3. Nova regra.
4. Porta.
5. TCP 3306.
6. Permitir conexão.
7. Marque rede privada.
8. Nomeie como `MySQL Farma Quantum`.

---

## 11. Pré-inicialização estrutural do banco

O sistema possui rotina de pré-inicialização estrutural. Ela deve:

- verificar banco escolhido;
- criar tabelas faltantes;
- criar colunas faltantes;
- criar índices;
- criar registros padrão;
- preparar tabelas de farmácia, lote, validade, tratamento, prontuário, CRM e relatórios.

Isso ajuda quando o sistema é instalado em banco novo ou banco antigo incompleto.

---

## 12. Primeiro login

Usuários administrativos blindados padrão:

- `adm`
- `phda`

Esses usuários devem manter acesso total e não devem perder permissões.

Após entrar:

1. Acesse usuários/permissões.
2. Crie usuários reais para balcão, caixa, estoque e gerência.
3. Defina permissões granulares.
4. Teste com um usuário comum antes de colocar em produção.

---

## 13. Instalação de impressora térmica 80mm ou 58mm

### 13.1. Via USB

1. Conecte a impressora.
2. Instale o driver do fabricante.
3. Verifique se aparece em `Dispositivos e Impressoras`.
4. Defina nome simples, por exemplo:
   - `IMP-CAIXA`
   - `IMP-BOBINA`
   - `IMP-COZINHA`

### 13.2. Driver genérico texto

Para impressoras ESC/POS simples, pode usar:

- Generic / Text Only.
- Porta USB virtual ou COM.

### 13.3. Bobina 80mm

Mais recomendada para cupom e comprovantes. Possui largura melhor para informações.

### 13.4. Bobina 58mm

Boa para ambientes pequenos, mas exige relatório mais compacto.

### 13.5. Testes

Faça testes com:

- cupom de venda;
- relatório bobina 80mm;
- relatório bobina 58mm;
- abertura de gaveta, se houver;
- acentuação;
- corte automático.

---

## 14. Instalação de impressora A4

Pode ser jato de tinta, laser ou PDF virtual.

Use para:

- relatórios gerenciais;
- prontuários;
- fichas ambulatoriais;
- relatórios de lote e validade;
- documentos administrativos.

Teste a impressão pelo navegador quando o relatório for HTML.

---

## 15. Leitor de código de barras

A maioria dos leitores USB funciona como teclado.

### 15.1. Instalação

1. Conecte o leitor USB.
2. Abra o Bloco de Notas.
3. Escaneie um produto.
4. Se aparecer o código, está funcionando.

### 15.2. Configuração recomendada

- Leitor deve enviar ENTER após leitura.
- Suporte a EAN-13, EAN-8, Code128 e QR quando necessário.
- Usar modo teclado HID.

### 15.3. Uso no sistema

Clique no campo de busca/código e escaneie. O sistema deve preencher o código como se tivesse sido digitado.

---

## 16. Balança comercial

### 16.1. Tipos de integração

- Serial RS-232.
- USB simulando COM.
- Bluetooth.
- Arquivo/texto intermediário.

### 16.2. Dependência necessária

```bat
pip install pyserial
```

### 16.3. Configurações importantes

- Porta COM: exemplo `COM3`.
- Baud rate: 9600, 4800 ou conforme fabricante.
- Paridade, bits e stop bits conforme manual da balança.

### 16.4. Teste

Use um terminal serial ou ferramenta do fabricante para verificar se o peso chega antes de testar no sistema.

---

## 17. Gaveta de dinheiro

A gaveta normalmente liga na impressora térmica via RJ11/RJ12. O comando de abertura é enviado pela impressora.

Verifique:

- se a impressora aceita comando ESC/POS;
- se o cabo da gaveta está correto;
- se o driver permite abrir gaveta após impressão.

---

## 18. Pin pad, TEF e cartões

A integração com TEF depende de contrato com adquirente/fornecedor.

Itens comuns:

- software TEF instalado;
- DLL/API do fornecedor;
- homologação fiscal/comercial;
- configuração por CNPJ/loja/terminal.

Sem TEF integrado, o sistema pode registrar forma de pagamento manualmente: crédito, débito, PIX, dinheiro, convênio.

---

## 19. WhatsApp e comunicação

O sistema pode abrir mensagens prontas para WhatsApp usando link web.

Requisitos:

- internet ativa;
- navegador padrão configurado;
- WhatsApp Web logado ou aplicativo instalado.

Use para:

- lembrete de recompra;
- tratamento contínuo;
- orientação farmacêutica;
- confirmação de serviço;
- campanha/oferta;
- CRM/pós-venda.

---

## 20. Compilar para EXE onefile sem console

Execute:

```bat
COMPILAR_EXE_NOCONSOLE_ONEFILE.bat
```

O PyInstaller deve gerar o executável dentro da pasta:

```text
dist\
```

O comando usa:

```bat
--onefile --noconsole --icon farmacia_moderno.ico
```

---

## 21. Solução de problemas na compilação

### 21.1. PyInstaller não encontrado

```bat
pip install pyinstaller
```

### 21.2. Módulo não encontrado

Instale a biblioteca:

```bat
pip install nome_do_modulo
```

### 21.3. Erro de antivírus

Alguns antivírus verificam executáveis gerados por PyInstaller. Adicione exceção na pasta de build ou assine digitalmente o executável em ambiente profissional.

### 21.4. EXE abre e fecha

Compile temporariamente com console para ver o erro:

```bat
pyinstaller --onefile Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
```

Depois corrija e volte para `--noconsole`.

---

## 22. Checklist final de instalação

Antes de usar em produção:

- [ ] Python instalado.
- [ ] Dependências instaladas.
- [ ] MySQL instalado e ativo.
- [ ] Banco criado.
- [ ] Usuário liberado.
- [ ] Sistema conecta ao banco.
- [ ] Tabelas criadas automaticamente.
- [ ] Usuário administrador entra.
- [ ] Usuários comuns criados.
- [ ] Permissões testadas.
- [ ] Impressora 80mm testada.
- [ ] Impressora 58mm testada, se usada.
- [ ] Impressora A4 testada.
- [ ] Leitor de código testado.
- [ ] Backup configurado.
- [ ] Rotina de validade testada.
- [ ] Rotina de tratamento contínuo testada.
- [ ] Prontuário testado.
- [ ] Relatórios testados.

---

## 23. Manutenção periódica

Diariamente:

- abrir sistema;
- verificar alertas;
- conferir vendas;
- conferir lote/validade;
- testar impressora;
- fazer backup.

Semanalmente:

- revisar usuários;
- conferir estoque baixo;
- exportar relatórios;
- testar restauração de backup.

Mensalmente:

- revisar permissões;
- limpar logs antigos se necessário;
- atualizar dependências em ambiente de teste;
- conferir integridade do banco.

---

## 24. Boas práticas

- Não use o usuário `root` no dia a dia.
- Não compartilhe senha de administrador.
- Cada funcionário deve ter seu próprio usuário.
- Caixa não deve ter permissão administrativa.
- Estoque não deve alterar vendas fechadas.
- Balconista não deve excluir registros críticos.
- Use backup antes de qualquer atualização.
- Teste nova versão fora do horário comercial.

---

## 25. Encerramento

Com este manual, a farmácia consegue instalar o sistema, configurar banco, compilar EXE, preparar equipamentos e iniciar uso com segurança. Para operação diária detalhada, consulte o manual de usuário completo. Para alterações técnicas, consulte o manual do desenvolvedor.
