# REQUISITOS, DEPENDÊNCIAS, PLUGINS E EQUIPAMENTOS — FARMA QUANTUM

Este documento concentra os requisitos para instalar, usar, compilar e integrar equipamentos ao Farma Quantum.

---

## 1. Sistemas operacionais suportados

### Recomendado

- Windows 10 Pro 64-bit.
- Windows 11 Pro 64-bit.

### Compatível com ajustes

- Windows 10 Home.
- Windows 11 Home.
- Windows Server.
- Linux com Python/Tkinter/MySQL, exigindo ajustes de impressão.

---

## 2. Hardware por função

### 2.1. Caixa / Balcão

- Core i3 ou superior.
- 4 GB RAM mínimo, 8 GB recomendado.
- SSD.
- Monitor 1366x768 ou maior.
- Leitor de código de barras USB.
- Impressora térmica 80mm.
- Gaveta conectada à impressora, opcional.

### 2.2. Gerência

- Core i5.
- 8 GB RAM.
- Impressora A4.
- Acesso a relatórios.
- Permissão administrativa.

### 2.3. Estoque

- Computador ou notebook simples.
- Leitor de código de barras.
- Impressora de etiqueta, se usada.
- Acesso a notas, lotes, validade e estoque.

### 2.4. Ambulatório farmacêutico

- Computador com tela confortável.
- Impressora A4.
- Equipamentos clínicos conforme serviço:
  - aparelho de pressão;
  - oxímetro;
  - termômetro;
  - glicosímetro;
  - balança corporal;
  - fita métrica/estadiômetro.

---

## 3. Dependências Python principais

```text
ttkbootstrap
mysql-connector-python
pillow
pyinstaller
reportlab
psutil
requests
```

### Função de cada uma

- `ttkbootstrap`: melhora aparência da interface.
- `mysql-connector-python`: conecta ao MySQL.
- `pillow`: manipula imagens e ícones.
- `pyinstaller`: gera `.exe`.
- `reportlab`: relatórios PDF quando usado.
- `psutil`: monitoramento de saúde do sistema.
- `requests`: integrações HTTP.

---

## 4. Dependências opcionais

```text
pyserial
bleak
pybluez
flask
python-escpos
pywin32
openpyxl
pandas
```

### Função de cada uma

- `pyserial`: comunicação serial com balanças, leitores e equipamentos COM.
- `bleak`: Bluetooth Low Energy.
- `pybluez`: Bluetooth clássico, quando suportado.
- `flask`: servidor web local/API/painéis.
- `python-escpos`: comandos ESC/POS para impressoras térmicas.
- `pywin32`: impressão e automação Windows.
- `openpyxl`: planilhas Excel.
- `pandas`: manipulação avançada de dados e relatórios.

---

## 5. MySQL

### Versões recomendadas

- MySQL 8.0.
- MySQL 5.7.
- MariaDB 10.x, com testes.

### Configuração recomendada

```ini
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci
bind-address=0.0.0.0
```

### Porta

```text
3306/TCP
```

---

## 6. Impressoras térmicas

### 6.1. Modelos comuns compatíveis em modo driver

- Bematech.
- Elgin.
- Epson TM.
- Daruma.
- Sweda.
- Goldentec.
- Tanca.
- POS-58 genéricas.
- POS-80 genéricas.

### 6.2. Protocolos

- Driver Windows.
- Generic/Text Only.
- ESC/POS.
- USB.
- Serial COM.
- Ethernet/IP.
- Bluetooth, se suportado.

### 6.3. Configurações importantes

- Largura 80mm ou 58mm.
- Codepage/acento.
- Corte automático.
- Abertura de gaveta.
- Velocidade de impressão.
- Margens.

### 6.4. Teste mínimo

- Imprimir texto comum.
- Imprimir cupom.
- Imprimir relatório bobina.
- Conferir acentos.
- Conferir alinhamento.
- Conferir corte.

---

## 7. Impressoras A4

Usadas para:

- relatórios completos;
- prontuários;
- documentos de atendimento;
- auditoria;
- listas gerenciais.

Podem ser:

- jato de tinta;
- laser;
- PDF virtual;
- impressora de rede.

---

## 8. Leitores de código de barras

### 8.1. USB HID

Mais fácil. Funciona como teclado.

Requisitos:

- EAN-13 para produtos comuns.
- EAN-8 para produtos menores.
- Code128 para códigos internos.
- QR Code se necessário.

### 8.2. Serial

Exige `pyserial` e configuração de porta.

### 8.3. Recomendação

Configurar leitor para enviar ENTER após leitura. Isso acelera venda e busca.

---

## 9. Balanças

### 9.1. Balança de checkout

Pode enviar peso para o sistema.

Requisitos:

- porta serial/USB;
- protocolo conhecido;
- `pyserial`;
- configuração de COM e velocidade.

### 9.2. Balança etiquetadora

Pode gerar etiqueta com código de barras contendo peso/preço. Nesse caso o sistema precisa interpretar o código lido.

Exemplo de padrões:

- prefixo 2 para produto pesável;
- código do produto;
- peso ou preço embutido;
- dígito verificador.

---

## 10. Gaveta de dinheiro

Normalmente depende da impressora. Requisitos:

- impressora com porta de gaveta;
- cabo RJ11/RJ12 correto;
- comando ESC/POS de abertura;
- driver configurado.

---

## 11. TEF / Pin Pad

Integração avançada e dependente de fornecedor.

Requisitos prováveis:

- contrato TEF;
- biblioteca/DLL homologada;
- configuração por loja;
- VPN ou comunicação segura;
- suporte da adquirente;
- homologação.

Sem isso, o sistema pode registrar pagamentos manualmente.

---

## 12. Equipamentos clínicos

O prontuário ambulatorial pode receber dados digitados manualmente. Integração automática depende do equipamento.

Possíveis equipamentos:

- glicosímetro com USB/Bluetooth;
- oxímetro Bluetooth;
- balança corporal digital;
- termômetro digital;
- aparelho de pressão.

Para integração automática, verificar:

- se o fabricante fornece API;
- se exporta CSV/TXT;
- se comunica por serial/Bluetooth;
- se há protocolo documentado.

---

## 13. Rede local

### Recomendado

- servidor com IP fixo;
- caixas na mesma rede;
- cabo de rede para caixa principal;
- roteador com reserva DHCP;
- firewall configurado.

### Testes

No terminal do caixa:

```bat
ping 192.168.0.100
```

Testar porta:

```bat
telnet 192.168.0.100 3306
```

Se telnet não existir, instalar recurso ou usar PowerShell quando disponível.

---

## 14. Segurança operacional

- Usar usuário MySQL específico do sistema.
- Não usar root no dia a dia.
- Senhas fortes.
- Backup diário.
- Permissões por funcionário.
- Bloquear exclusões para usuários comuns.
- Auditar acesso a prontuários.
- Não deixar banco exposto para internet.

---

## 15. Plugins futuros sugeridos

- Plugin de NF-e/NFC-e, se houver integração fiscal homologada.
- Plugin de PBM específico por fornecedor.
- Plugin de TEF.
- Plugin de SNGPC conforme necessidade legal e técnica.
- Plugin de etiquetas.
- Plugin de balança por fabricante.
- Plugin de WhatsApp API oficial.
- Plugin de backup em nuvem.
- Plugin de dashboard web.

---

## 16. Checklist de equipamentos

- [ ] Impressora térmica 80mm instalada.
- [ ] Impressora 58mm testada, se usada.
- [ ] Impressora A4 instalada.
- [ ] Leitor USB testado no Bloco de Notas.
- [ ] Gaveta abre pela impressora.
- [ ] Balança comunica, se usada.
- [ ] Rede local estável.
- [ ] MySQL acessível.
- [ ] Backup definido.
- [ ] Nobreak instalado.

---

## 17. Observações comerciais

Em farmácias e drogarias, estabilidade é mais importante que excesso de recursos. Recursos críticos devem ser testados antes de entrar em produção, principalmente:

- vendas;
- impressão;
- estoque;
- validade;
- permissões;
- prontuário;
- backup.
