# MANUAL DO DESENVOLVEDOR — FARMA QUANTUM

**Objetivo:** orientar manutenção, evolução, análise, empacotamento e integração do sistema Farma Quantum por um futuro desenvolvedor.

---

## 1. Visão técnica geral

O sistema é uma aplicação desktop Python baseada principalmente em:

- Tkinter / ttk / ttkbootstrap para interface gráfica.
- MySQL como banco principal.
- JSON como armazenamento local complementar para módulos isolados.
- PyInstaller para empacotamento em `.exe`.
- Rotinas de auditoria em arquivo.
- Patches incrementais preservando funcionalidades anteriores.

A arquitetura atual é monolítica, com módulos adicionados ao mesmo arquivo para facilitar distribuição em um único `.py` e posterior geração de `.exe` onefile.

---

## 2. Filosofia de manutenção

Regra principal: **não remover funcionalidades existentes sem mapeamento e teste**.

Ao alterar:

1. Faça cópia do arquivo atual.
2. Aplique patch incremental.
3. Valide sintaxe com `py_compile`.
4. Rode o sistema com console em ambiente de teste.
5. Teste menus alterados.
6. Teste usuário administrador e usuário restrito.
7. Teste conexão MySQL.
8. Teste relatórios e impressão.
9. Só então gere `.exe`.

---

## 3. Estrutura de pastas recomendada

```text
C:\Quantum\
  Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
  config.ini
  pdv_data\
    config.json
    farmacia_pro.json
    tratamentos_continuos.json
    prontuario_ambulatorial.json
  auditoria\
  relatorios_farmacia\
  backup\
  logs\
```

Durante desenvolvimento, manter também:

```text
src\
patches\
build_tools\
docs\
tests\
```

---

## 4. Principais áreas funcionais

### 4.1. Boot e inicialização

Responsável por:

- instância única;
- splash;
- carregamento visual;
- leitura de config;
- conexão com banco;
- pré-inicialização de schema;
- autenticação;
- abertura da aplicação principal;
- tarefas em segundo plano.

Ao mexer no boot, cuidado com travamentos antes da interface aparecer.

### 4.2. Configuração MySQL

Inclui:

- tela inicial de banco;
- leitura/gravação de `config.ini`;
- teste de conexão;
- criação de banco/usuário;
- liberação de permissões;
- geração de SQL;
- tentativa de bind-address.

Deve ser robusta, pois é o primeiro contato do usuário com o sistema.

### 4.3. Pré-inicialização de schema

Deve criar sem apagar:

- tabelas;
- colunas;
- índices;
- registros padrão;
- ajustes de charset.

Use `CREATE TABLE IF NOT EXISTS` e `ALTER TABLE ADD COLUMN` somente quando a coluna não existir.

### 4.4. Permissões granulares

Deve permitir controle por:

- módulo;
- tela;
- botão;
- campo;
- ação;
- impressão;
- exportação;
- administração.

Administradores blindados devem sempre ter acesso total.

### 4.5. Módulos farmacêuticos

Incluem:

- lote e validade;
- tratamento contínuo;
- prontuário ambulatorial;
- Farmácia Pro;
- receituário/controlados/SNGPC;
- PBM/convênios;
- serviços farmacêuticos;
- CRM;
- relatórios A4 e bobina.

---

## 5. Convenções de código

### 5.1. Nomes de funções

Usar prefixos para patches:

```python
_farmacia_
_farmaz_
_schema_
_perm_
_rf_
_amb_
_tc_
```

### 5.2. Tratamento de exceções

Nunca deixar botão de interface derrubar o sistema sem mensagem amigável.

Preferir:

```python
try:
    executar_algo()
except Exception as e:
    messagebox.showerror('Erro', f'Não foi possível executar:\n{e}')
```

E registrar auditoria quando disponível.

### 5.3. Compatibilidade Tkinter/ttkbootstrap

Evitar opções não suportadas por todas as versões:

- `padding` diretamente em `LabelFrame` pode falhar.
- `PanedWindow` pode estar como `Panedwindow`.
- `DateEntry` pode não existir.

Criar fallbacks.

---

## 6. Banco de dados

### 6.1. Charset

Usar:

```sql
utf8mb4
utf8mb4_unicode_ci
```

### 6.2. Tipos comuns

- IDs: `INT AUTO_INCREMENT PRIMARY KEY`.
- Textos curtos: `VARCHAR(255)`.
- Textos longos: `TEXT`.
- Valores: `DECIMAL(10,2)` ou maior quando necessário.
- Datas: `DATE`.
- Data/hora: `DATETIME`.
- Flags: `TINYINT(1)`.

### 6.3. Tabelas farmacêuticas sugeridas

- `produtos`
- `clientes`
- `fornecedores`
- `usuarios`
- `vendas`
- `vendas_itens`
- `notas_entrada`
- `estoque_lotes`
- `tratamentos_continuos`
- `prontuario_ambulatorial`
- `receituario_controlados`
- `pbm_convenios`
- `campanhas_farmacia`
- `servicos_farmaceuticos`
- `crm_farmacia`
- `permissoes`
- `perfis`
- `auditoria`

---

## 7. Estratégia de migração segura

Ao adicionar nova coluna:

1. Verificar se tabela existe.
2. Verificar se coluna existe em `information_schema.columns`.
3. Adicionar coluna se faltar.
4. Criar índice se necessário.
5. Não apagar dados.
6. Registrar no console.

Exemplo conceitual:

```python
def ensure_column(cursor, table, column, definition):
    cursor.execute("""
        SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = %s
          AND column_name = %s
    """, (table, column))
    exists = cursor.fetchone()[0] > 0
    if not exists:
        cursor.execute(f"ALTER TABLE `{table}` ADD COLUMN `{column}` {definition}")
```

---

## 8. Permissões atômicas

### 8.1. Formato sugerido

```text
modulo.tela.componente.acao
```

Exemplos:

```text
produto.cadastro.botao.salvar
produto.cadastro.campo.preco.editar
venda.caixa.botao.finalizar
relatorio.farmacia.a4.imprimir
ambulatorio.prontuario.memo.conduta.editar
mysql.config.botao.bind_address.executar
```

### 8.2. Regras

- `*` libera tudo.
- `produto.*` libera módulo produto.
- Permissão exata libera ação específica.
- Permissão negada deve bloquear botão/campo e registrar auditoria.
- Administrador blindado ignora bloqueios.

### 8.3. Como aplicar em componentes

Ao criar botão:

```python
btn = ttk.Button(...)
proteger_componente(btn, 'produto.cadastro.botao.salvar')
```

Ao criar campo:

```python
entry = ttk.Entry(...)
proteger_componente(entry, 'produto.cadastro.campo.preco.editar')
```

Se sem permissão:

- botão fica desativado;
- campo fica readonly/disabled;
- menu pode ficar oculto ou desabilitado;
- tentativa de execução direta é barrada.

---

## 9. Relatórios

Relatórios devem suportar:

- A4 HTML/PDF;
- bobina 80mm TXT;
- bobina 58mm TXT;
- prévia em tela;
- abertura do último relatório;
- impressão direta quando possível.

### 9.1. A4

Usar HTML com CSS para impressão. Boa opção para abrir no navegador.

### 9.2. Bobina

Gerar texto com largura limitada.

Larguras aproximadas:

- 80mm: 42 a 48 caracteres por linha.
- 58mm: 30 a 32 caracteres por linha.

---

## 10. Impressoras

### 10.1. Impressão via Windows

Pode usar:

- `os.startfile(arquivo, 'print')`;
- `win32print` quando `pywin32` estiver instalado;
- driver padrão do Windows.

### 10.2. ESC/POS

Para impressão térmica avançada:

- `python-escpos`;
- comandos ESC/POS manuais;
- USB, rede ou serial.

### 10.3. Cuidados

- acentuação pode variar por codepage;
- corte automático depende da impressora;
- gaveta depende da impressora;
- imagens/logos aumentam lentidão em bobina.

---

## 11. Leitores de código

Se o leitor for HID teclado, não precisa biblioteca. Basta foco no campo.

Se for serial/USB especial, usar:

- `pyserial`;
- configuração de porta;
- thread de leitura;
- fila segura para atualizar UI.

Nunca atualizar Tkinter direto de thread secundária; use `root.after`.

---

## 12. Balanças

Integrações com balança precisam tratar:

- porta COM;
- baud rate;
- protocolo do fabricante;
- estabilidade do peso;
- tara;
- timeout;
- desconexão.

Fluxo recomendado:

1. Detectar portas COM.
2. Permitir escolha manual.
3. Testar leitura.
4. Salvar configuração.
5. Ler em thread.
6. Aplicar peso somente quando estável.

---

## 13. Bluetooth

Dependências possíveis:

- `bleak` para BLE moderno.
- `pybluez` para Bluetooth clássico, quando compatível.

Bluetooth no Windows pode variar conforme adaptador e driver.

---

## 14. Flask / servidor local

Pode ser usado para:

- painel de senhas;
- comandas web;
- relatórios web;
- API local;
- integração com outros terminais.

Cuidados:

- não expor sem autenticação;
- limitar rede local;
- registrar logs;
- usar porta configurável;
- tratar firewall.

---

## 15. Segurança

### 15.1. Senhas

Não salvar senha pura quando possível. Usar hash para usuários do sistema.

Para senha do banco em `config.ini`, proteger o acesso ao arquivo e não compartilhar.

### 15.2. Auditoria

Registrar:

- login;
- falha de login;
- alteração de permissão;
- exclusão;
- cancelamento de venda;
- alteração de estoque;
- impressão de relatório crítico;
- acesso a prontuário;
- dados sensíveis.

### 15.3. LGPD

Prontuário e dados pessoais exigem cuidado. Deve haver:

- controle de acesso;
- registro de acesso;
- backup seguro;
- não exposição desnecessária;
- política de retenção.

---

## 16. Performance

Recomendações:

- carregar tela rapidamente;
- adiar tarefas pesadas;
- usar paginação em listagens grandes;
- usar índices em campos de busca;
- evitar consultas sem filtro em tabelas enormes;
- não bloquear UI com loops longos;
- usar threads com cuidado.

---

## 17. Testes obrigatórios antes de publicar

### 17.1. Teste de inicialização

- sem config.ini;
- com config.ini correto;
- com config.ini errado;
- MySQL desligado;
- MySQL ligado;
- banco inexistente;
- banco incompleto.

### 17.2. Teste de usuários

- adm entra;
- phda entra;
- usuário comum entra;
- usuário sem permissão é bloqueado;
- perfil rápido aplica corretamente;
- botão sem permissão fica indisponível.

### 17.3. Teste farmacêutico

- produto com validade;
- produto sem validade;
- alerta 15 dias antes;
- alerta no dia;
- alerta vencido;
- tratamento contínuo;
- prontuário;
- relatório.

### 17.4. Teste de impressão

- A4;
- 80mm;
- 58mm;
- acentuação;
- corte;
- impressora ausente;
- erro de driver.

---

## 18. Empacotamento

Use PyInstaller.

Comando base:

```bat
pyinstaller --onefile --noconsole --icon farmacia_moderno.ico Quantum_Farmacia_PENTE_FINO_CORRIGIDO.py
```

Quando houver arquivos adicionais, usar `.spec`.

---

## 19. Diagnóstico em ambiente do cliente

Se o EXE não abrir:

1. Rodar versão com console.
2. Verificar auditoria.
3. Verificar permissões de pasta.
4. Verificar antivírus.
5. Verificar MySQL.
6. Verificar DLLs e dependências.
7. Testar em pasta simples: `C:\Quantum`.

---

## 20. Como evoluir o sistema

Sugestões futuras:

- separar módulos em arquivos;
- criar camada DAO/repositório;
- criar testes automatizados;
- criar migrações versionadas;
- assinar digitalmente o EXE;
- criar instalador MSI/NSIS;
- criptografar config sensível;
- criar API local documentada;
- criar backup automático com restauração guiada;
- criar logs estruturados em JSON;
- criar painel web responsivo.

---

## 21. Checklist do desenvolvedor

Antes de entregar nova versão:

- [ ] Backup da versão anterior.
- [ ] Sintaxe validada.
- [ ] Inicialização testada.
- [ ] Login testado.
- [ ] Banco novo testado.
- [ ] Banco antigo testado.
- [ ] Permissões testadas.
- [ ] Menus testados.
- [ ] Impressão testada.
- [ ] Relatórios testados.
- [ ] EXE gerado.
- [ ] EXE testado em pasta limpa.
- [ ] Manual atualizado.
- [ ] Nome da versão anotado.

---

## 22. Conclusão técnica

O Farma Quantum é um sistema grande, comercial e sensível, por lidar com vendas, estoque, pacientes, prontuário, tratamentos e permissões. O desenvolvimento deve priorizar estabilidade, rastreabilidade, compatibilidade e manutenção incremental segura.
